# Kurumsal Temel Değişmezler (Foundational Invariants K-01 — K-12)

Bu belge, Kampüs PTS Gelir Yönetim Platformu'nun teknik, hukuki ve operasyonel değişmezlerini (K-01 ila K-12) tanımlar. `AGENTS.md` içindeki A1–A10 mimari kuralları ile tam bir uyum içindedir.

---

### K-01: Tek Gerçek Kaynağı ve Modül Bağımsızlığı (Single Source of Truth)
Her veri alanının (`Domain Entity`) tek bir sahibi modül vardır. Hiçbir modül başka bir modülün veritabanı şemasına veya tablolarına doğrudan sorgu atamaz veya kayıt ekleyemez (`Fact Owner = Command Owner = Domain Event Owner`). Modüller arası veri akışı yalnızca domain olayları ve onaylı uygulama portları üzerinden gerçekleşir.

### K-02: Fiziksel Güvenlik ve İSG Önceliği (Safety Interlocks Override Software)
Saha güvenliği, araç sıkışma koruması (fotosel), yangın tahliye otomasyonu ve acil durum butonu gibi donanımsal güvenlik zincirleri tüm yazılım komutlarının mutlak üstündedir. PTS yazılımı donanımsal güvenlik interlocklarını hiçbir koşulda baypas edemez veya geçersiz kılamaz.

### K-03: ASManager Entegrasyon Sınırı ve Veritabanı Yalıtımı (ASManager DB Isolation)
Mevcut GV-ASManager 6.3.0 sistemi personelin fiziksel geçiş haklarının yegane yetkili otoritesidir. PTS, ASManager veritabanına doğrudan SQL yazamaz; şemasını tersine mühendislikle değiştiremez. İletişim yalnızca doğrulanmış resmi API veya onaylı iş emri kanalları üzerinden yürütülür. Doğrulanmamış vendor endpoint veya SDK kabiliyeti icat edilemez.

### K-04: Mali Hak ile Fiziksel Hak Ayrımı (Financial vs Access Rights Separation)
Finansal bir aboneliğin aktif olması (`financial=ACTIVE`), fiziksel bariyer geçiş yetkisini kendiliğinden açmaz (`access=VERIFIED_ACTIVE`). Fiziksel yetkilendirme ASManager tarafından doğrulanmış iş emri teyidine kadar ayrı bir durum olarak bağımsız izlenir.

### K-05: Gözlem ile Kesin Geçiş Kanıtı Ayrımı (Observation vs Confirmed Passage)
Kameranın plakayı okuması (`PlateObservation` / `PLATE_RECOGNIZED`), aracın bariyeri fiziksel olarak aştığını kanıtlamaz (`PassageEvidence` / `PASSAGE_CONFIRMED`). Bariyer kumandası (`GateCommand`) ve bariyer teyidi (`GateAck`) ayrı olgulardır. Salt plaka görüntüsüyle kesin giriş-çıkış, tahakkuk veya bariyer başarısı ilan edilemez.

### K-06: Ödeme Idempotency ve Durum Makinesi (Payment Idempotency & Lifecycle)
Ödeme nesneleri katı bir durum makinesine tabidir (`Quote` → `Charge` → `PaymentIntent` → `PaymentTransaction` → `ProviderSettlement` → `Invoice` → `JournalEntry` → `ERPPosting`). PSP sunucusundan sunucu-sunucu doğrulanmış yanıt alınmadan ödeme `SUCCESS` kabul edilemez; `CAPTURED` bankada `SETTLED` anlamına gelmez. Mükerrer ödemeler ve tekrarlı webhook bildirimleri kriptografik `idempotencyKey` ile önlenir.

### K-07: Mali Yetki Matrisi ve Rol Ayrılığı (Financial Authority Matrix & SoD)
Gelir Sahibi (`RevenueOwner`), Tahsilatçı (`Collector`), Kayıtlı Satıcı (`MerchantOfRecord`), Hakediş Sahibi (`SettlementBeneficiary`), Fatura Düzenleyen (`InvoiceIssuer`), Muhasebe Otoritesi (`AccountingAuthority`) ve Vergi Politikası Sahibi (`TaxPolicyOwner`) ayrı rollerdir. Kurumsal üst yönetimce DEC-001 (A/B/C/D seçenekleri) onaylanana kadar hiçbir model kesin kabul edilemez. Hukuki yetkisi doğrulanmamış otopark dışı hizmetler ücretlendirilemez (`DEC-027`).

### K-08: Değişmez Alt Defter ve Ters Kayıt Disiplini (Immutable Sub-ledger & Reversals)
PTS alt defterinde `POSTED` statüsüne geçen hiçbir muhasebe kaydı silinemez veya güncellenemez. Hatalı veya iade işlemleri yalnızca eşit ve zıt tutarlı bir ters kayıt (`reversal`) ile dengelenir. Çift taraflı borç/alacak denkliği korunur. Nihai yasal muhasebe otoritesi PTS değil, onaylanmış kurumsal ERP'dir.

### K-09: Bilgi Durumu Dürüstlüğü (Epistemic Truth)
Bilinmeyen durum yanlış değildir (`UNKNOWN ≠ FALSE`). Tasarlanan test koşulmuş test değildir (`DESIGNED ≠ TESTED`). Koşulmamış test geçmiş sayılamaz (`NOT_RUN ≠ PASS`). Yapay zeka veya varsayımlar kurumsal onay makamı yerine geçemez (`AI ≠ Institutional Authority`). Eksik tüm koşullar açıkça `DECISION_REQUIRED`, `TO_VERIFY`, `BLOCKER` veya `NOT_AVAILABLE` olarak gösterilir.

### K-10: Hassas Veri ve KVKK/PCI-DSS Koruması (PII & Cardholder Protection)
Kredi kartı PAN/CVV verisi hiçbir şekilde sistemde saklanmaz. Gerçek plaka, kimlik numarası, telefon numarası, kişisel fotoğraf ve banka hesap verileri loglara, istemci taraflı koda veya test fixture'larına maskesiz konulamaz. Tüm API anahtarları sunucu tarafı gizli kasalarda tutulur.

### K-11: Dayanıklı Mesajlaşma ve Outbox Deseni (Durable Outbox & Event Envelope)
Modüller arası tüm asenkron iletişim `Transactional Outbox` deseni ile garantiye alınır. Olaylar standart `event-envelope.schema.json` formatında yayımlanır; kayıpsız iletim, at-least-once teslim ve tüketici tarafında idempotent işleme zorunludur.

### K-12: Test ve Kanıt Doğruluğu (Test and Evidence Veracity)
Gerçekte koşulmamış hiçbir test için `PASS` sonucu veya sahte kanıt (`EVD-*`) üretilemez. Bir kalite kapısının (G0–G9) geçilebilmesi için fiziksel olarak mevcut, imzalanmış ve hash doğrulaması yapılmış kanıt zorunludur. Tasarlanmış testler koşulana kadar dürüstçe `NOT_RUN` ve `EVD=NONE` olarak raporlanır.
