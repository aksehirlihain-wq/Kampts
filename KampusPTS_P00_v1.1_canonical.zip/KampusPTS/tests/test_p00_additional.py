#!/usr/bin/env python3
"""
test_p00_additional.py — Additional Independent Regression Tests for KampusPTS P00
Validates semantic invariants:
1. K-12 is Test and Evidence Veracity
2. DEC-001 options A/B/C/D exact semantics
3. Gate phase ranges G1=P01-P04 to G9=P32-P33
4. Feature flags strict false contracts
5. Blockers and Traceability reference integrity
"""

import unittest
from pathlib import Path
import sys
import json
import csv

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
sys.path.insert(0, str(PROJECT_ROOT / "tools"))

from validate_p00 import find_project_root, read_csv_rows


class TestP00Additional(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = find_project_root()

    def test_k12_invariant_veracity(self):
        invariants_file = self.root / "docs" / "governance" / "foundational-invariants.md"
        content = invariants_file.read_text(encoding="utf-8")
        self.assertIn("K-12: Test ve Kanıt Doğruluğu", content)
        self.assertNotIn("72 saatlik yerel arabellek", content)

    def test_dec_001_exact_alternatives(self):
        dec_file = self.root / "docs" / "registries" / "decisions.csv"
        rows, _ = read_csv_rows(dec_file)
        dec1 = next(r for r in rows if r["id"] == "DEC-001")
        self.assertEqual(dec1["status"], "DECISION_REQUIRED")
        self.assertEqual(dec1["actual_owner"], "TO_ASSIGN")
        self.assertEqual(dec1["due_date"], "TBD")
        opts = dec1["options"]
        self.assertIn("A Üniversite", opts)
        self.assertIn("B Döner sermaye", opts)
        self.assertIn("C Özel işletmeci", opts)
        self.assertIn("D Çoklu tüzel kişilik", opts)

    def test_dec_008_unknown_status(self):
        dec_file = self.root / "docs" / "registries" / "decisions.csv"
        rows, _ = read_csv_rows(dec_file)
        dec8 = next(r for r in rows if r["id"] == "DEC-008")
        self.assertIn("UNKNOWN", dec8["options"])

    def test_dec_027_authority(self):
        dec_file = self.root / "docs" / "registries" / "decisions.csv"
        rows, _ = read_csv_rows(dec_file)
        dec27 = next(r for r in rows if r["id"] == "DEC-027")
        self.assertIn("Otopark Dışı", dec27["title"])

    def test_gate_semantic_phase_ranges(self):
        gate_file = self.root / "docs" / "registries" / "gates.csv"
        rows, _ = read_csv_rows(gate_file)
        gate_map = {r["id"]: r["phase_range"] for r in rows}
        self.assertEqual(gate_map["G0"], "P00")
        self.assertIn("P01", gate_map["G1"])
        self.assertIn("P04", gate_map["G1"])
        self.assertIn("P05", gate_map["G2"])
        self.assertIn("P06", gate_map["G2"])
        self.assertIn("P07", gate_map["G3"])
        self.assertIn("P10", gate_map["G3"])
        self.assertIn("P11", gate_map["G4"])
        self.assertIn("P15", gate_map["G4"])
        self.assertIn("P16", gate_map["G5"])
        self.assertIn("P19", gate_map["G5"])
        self.assertIn("P20", gate_map["G6"])
        self.assertIn("P22", gate_map["G6"])
        self.assertIn("P23", gate_map["G7"])
        self.assertIn("P28", gate_map["G7"])
        self.assertIn("P29", gate_map["G8"])
        self.assertIn("P31", gate_map["G8"])
        self.assertIn("P32", gate_map["G9"])
        self.assertIn("P33", gate_map["G9"])

    def test_blocker_reference_integrity(self):
        blk_file = self.root / "docs" / "registries" / "blockers.csv"
        rows, _ = read_csv_rows(blk_file)
        for r in rows:
            self.assertTrue(r["decision_ids"])
            self.assertTrue(r["gates"])
            self.assertEqual(r["status"], "OPEN")

    def test_features_contract_zero_live(self):
        cfg_file = self.root / "config" / "features.example.json"
        with open(cfg_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        features = data["features"]
        self.assertFalse(features["gateRealCommandsEnabled"])
        self.assertFalse(features["paymentRealCaptureEnabled"])
        self.assertFalse(features["eDocumentRealIssueEnabled"])
        self.assertFalse(features["erpRealPostingEnabled"])
        self.assertFalse(features["multiEntitySplitSettlementEnabled"])


if __name__ == "__main__":
    unittest.main()
