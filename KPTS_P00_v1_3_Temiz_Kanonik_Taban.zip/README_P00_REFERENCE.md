# KPTS P00 — REFERANS PAKETİ / DEĞİŞTİRİLMEZ KAYNAK

Bu arşiv 30.10.2026 tarihinde kullanıcı tarafından sağlanan `KampusPTS_P00_P76_Butunlesik_Teknik_Paket_v1_76.zip` içinden seçilmiş **orijinal dosyaları** içerir. Yeni uygulamanın P00 geliştirmesinde veri kaynağı olarak kullanılmalıdır.

**Önemli:** Bu, derlenmiş veya çalışır bir ürün değildir; P00 amaçlı kaynak bağlamıdır. G0 NOT_APPROVED; G5/G6/G7 NO-GO. Kaynak bütünlüğü doğrulaması işletim testi veya kurum kabulü değildir.

- `P00_REFERENCE/` içindekiler referans kabul edilir; değişiklikler yeni proje çalışma ağacında ayrı tutulur.
- P00 doğrulayıcısının özgün CSV durumları/sayıları korunmalıdır.
- P01 ve P05 dosyaları yalnız ileriki aşamaları doğru konumlandırmak için; P01–P76 uygulaması bu aşamada üretilmemelidir.
- `file-sha256.json` seçili dosyaların ham SHA-256 parmak izleridir.
- AI Studio ZIP'i doğrudan okuyamıyorsa, içeriği GitHub deposu olarak içe aktarın veya dosyaları açarak verin; erişemediği referansları görmüş gibi davranmamalıdır.
