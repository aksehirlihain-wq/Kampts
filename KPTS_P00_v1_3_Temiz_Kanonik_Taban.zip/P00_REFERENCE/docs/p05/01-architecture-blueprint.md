# P05-01 | Bağlam, karar hedefleri ve C4 mimari
**Durum:** PROPOSED / DESIGNED_NOT_APPROVED · Tarih: 2026-10-21

## 1. Mimari kalite hedefleri
1. Marka bağımsızlık: ASManager, GV-LPR ve diğer üreticiler adaptör ile izole edilir. Dış kaynaklardan gelen olayların alanları üretici belgesi + saha kanıtı olmadan kesinleştirilmez.
2. Otorite ayrımı: fiziksel personel erişim otoritesi mevcut GV-ASManager; ziyaretçi mali hakları/oturum/tarife PTS; bariyer fiziki kumandası saha kararı (`DEC-008`) bekler; ERP nihai kayıt otoritesidir.
3. Tek iş verisi sahibi: **Fact owner = Command owner = Domain event owner**; okuma modeli projeksiyonları hakikat sahibi değildir. Modüller arası tablo yazımı ve bağımsız tablolar arası gizli FK yasak.
4. Çoklu tüzel kişilik: Tenant, Campus, ParkingArea, Service, LegalEntity, ContractVersion, MerchantAccount, InvoiceIssuer, ERPCompany ayrı kimlikler ve sürümler. Finansal yönlendirme kuralsız ise `UNRESOLVED`, üretime çıkış yok.
5. İddia/kanıt: `PlateObservation` ≠ `PassageEvidence` ≠ `GateAck`; `Quote` ≠ `Charge` ≠ `PaymentTransaction` ≠ `Invoice` ≠ `JournalEntry`.
6. Süre ve para: olay kaydı UTC, Europe/Istanbul sunum; fiyat için bigint TRY kuruş, oran/vergide decimal; rounding politikası DEC bekler.

## 2. Referans dağıtım birimleri
- **Merkez API:** ASP.NET Core .NET 10; modüler monolit, başlangıçta tek dağıtım; modüllerin application/domain katmanı ayrık.
- **Workers:** Inbox, Outbox, Reconciliation, scheduler ve adapter workloads; ayrı process olabilir, Domain/Contracts ortak, aynı veritabanını schema owner ilkesine uygun kullanır.
- **Saha Device Gateway:** ayrı ağ segmentinde adaptörler ve şifreli kalıcı kuyruk (kapasite P01 NFR verisiyle kararlaştırılır); uzak merkezden bağımsız mevcut fiziksel can güvenliği.
- **PostgreSQL 16+:** ilk öneri tek cluster / modül başına mantıksal schema ve ayrık DB rolleri; tenant izolasyonu uygulama ve DB korumalarıyla. Veritabanı/tenant bazlı ayrıştırma ileride ADR + yasal inceleme ile seçilebilir.
- **React+TypeScript yönetim UI:** yalnız yetkilendirilmiş backend API; cihaz SDK, DB ve PSP anahtarına doğrudan erişim YOK.
- **Dış sistemler:** GV-ASManager (fiziksel hak SoT), kameralar, banka/PSP, e-belge özel entegratörü, ERP, IAM (OIDC), öğrenci/personel kaynakları.

## 3. Bağımlılık yönü
API / Worker → Modules.{Application} → Modules.{Domain}; Modules.{Infrastructure} implements Application ports. `SharedKernel` yalnız teknik değer tiplerini içerir. Bir modül başka modülün Infrastructure veya tablo modelini referans alamaz. Modules arası Contract/API veya Outbox eventi uygulanır. Reporting/Audit salt okunur olay tüketicisidir, asıl veri sahibi değildir.

## 4. Akış
Saha cihazı → Device Gateway adapter → raw hash + durable inbox → normalized PlateObservation → PassageEvidence correlator → Sessions → Quote/Charge → Payments server-side verification → Ledger → Invoicing/ERP + Reconciliation. Gate mali kararını üretse dahi fiziksel aktüatöre doğrudan komut YOK; `IGateController` açılması yetkili onay ve test gerektirir.

## 5. Dış bağlantılar ve güven sınırları
- Saha adaptörü `untrusted input`: giriş doğrulama, rate limit, imzalı/sertifikalı kanal imkanının **vendor bazında doğrulanması**, replay kontrolü, immutable raw hash; plaka güven puanı karar mercii değil.
- PSP/e-belge/ERP `third-party`: sır kasası, tenant+legalEntity scope, webhook replay koruması, sağlayıcı tarafından doğrulama, egress allowlist.
- Yönetim kullanıcıları `untrusted UI`: OIDC, MFA, role+scope+SoD, server-side filtering ve denetim.
- Bütün sistemde varsayılan özellik bayrakları `OFF`; canlı endpointler sözleşme, güvenlik ve kurumsal karar kapılarına bağlı.

## 6. Bilinmeyenler
Saha kapasitesi, geçiş kanıt kaynağı, ASManager payload, kamera firmware ve üretici eşzamanlı kullanım, yasal belge düzenleyicisi, PSP sözleşmesi, ERP hedefi, DR hedefleri: `TO_VERIFY/DECISION_REQUIRED`. Kesin rakam veya gerçek API iddiası yok.
