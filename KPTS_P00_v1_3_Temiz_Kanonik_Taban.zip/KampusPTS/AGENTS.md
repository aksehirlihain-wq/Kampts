# AGENTS.md — KAMPÜS PTS Değişmez Proje Kuralları (A1–A10)

> **Statü:** P00 taslak, sponsor onayı beklenir. Bu kurallar önerilen bağlayıcı teknik sözleşmedir; kurumsal karar yerine geçmez. Tasarımın önceki v2.1 kırmızı çizgileri korunur.

## A1 — Rol, dil, doğruluk
- Kapsam disiplinleri: çözüm mimarisi; C#/.NET 10 ve React; saha PTS; ödeme; e-belge; ERP; güvenlik/KVKK/İSG; QA/SRE.
- İletişim Türkçe; kod, API, tablo ve olay adları İngilizce; son kullanıcı etiketleri Türkçe.
- `UNKNOWN` gerçek `FALSE` değildir; `NOT_RUN` hiçbir zaman `PASS` değildir. AI kurumsal otorite değildir.
- Gerçek donanım/API/SDK/endpoints uydurma. Eksik kritik karar için `DECISION_REQUIRED` + sahip + gerekli kapı; gerekli kanıt için `BLOCKER` kaydı.
- Gerçek plaka, fotoğraf, TCKN/VKN, anahtar veya kart bilgisi maskesiz prompt/test artefaktına eklenmez.

## A2 — Fiziksel/mali otorite sınırı
- GV-ASManager 6.3.0 ve GV-LPR2812-DL mevcut saha sistemidir; üretici uyumluluğu kanıt bekler. Fiziksel personel erişim otoritesi ASManager'dır; PTS onun DB/schema'sına yazmaz, tersine mühendislik yapmaz.
- PTS: finansal abonelik, ziyaretçi mali oturumu, tarife, ücret/tahakkuk, ödeme ve mali çıkış kararı sahibidir. Mali `ALLOW` ≠ fiziksel bariyer açıldı.
- ASManager erişim tanımı için onaylı süreç/iş emri; `financial=ACTIVE` ≠ `access=VERIFIED_ACTIVE`. Erişim hakkı günlük mutabakatla teyit edilir.
- Gerçek bariyer kumandasının sahibi `DEC-008` kapsamında `UNKNOWN`; paralel röle/bypass yok. Can güvenliği ve tahliye yazılımdan bağımsızdır.
- Muhasebede PTS bir alt defterdir; yasal/nihai otorite ilgili kurum ERP'si veya onaylanmış mali kayıt sistemidir.

## A3 — Teknoloji ve bağımlılık kuralları
- Mimari: modüler monolit, ASP.NET Core/.NET 10 LTS, PostgreSQL 16+, EF Core, Worker, OpenAPI 3.1, React+TS. Referans tasarım; teknoloji ADR ile değiştirilebilir.
- Modüllerde Domain saf, Application iş kuralları, Infrastructure port implementasyonu; Api/Worker giriş uçları. Diğer modülün veritabanına doğrudan erişim veya çapraz schema write yok.
- Transactional outbox/inbox, idempotency, sürümlü sözleşmeler; yeni broker ancak ölçüm + ADR ile.
- UTC `timestamptz`, Türkiye yerel gösterimi `Europe/Istanbul`; saat/NTP tutarlılığı test edilmeden canlı karar yok.
- TRY saklama `bigint` kuruş, vergi/iskonto hesapları `decimal` ve tek onaylı yuvarlama politikası; `float` yasak. UUIDv7 uygulama tarafında oluşturulur.
- Docker Compose yalnız dev/test başlangıç altyapısıdır; üretim dağıtımı ayrı `DEC-018`.

## A4 — Kesin güvenlik ve mevzuat sınırları
1. PLATE_RECOGNIZED ≠ PASSAGE_CONFIRMED ≠ GATE_ACK; sensör/kontrolör kanıtı yoksa kesin geçiş veya ücretli oturum atfetme.
2. Bulanık plaka eşleşmesi sadece inceleme önerisidir; kendiliğinden muafiyet verilmez.
3. Bilinmeyen hak veya ödeme durumu bedelsiz/başarılı sayılmaz; inceleme ve sağlayıcı sorgusu uygulanır.
4. Gerçek gate/payment/e-belge `OFF`; devreye alma ayrı ortam, gerçek kanıt, iki ayrı onay ve kill-switch gerektirir.
5. Emniyet devreleri, yangın tahliyesi ve anti-sıkışma bağımsızdır.
6. PCI kapsamı daraltılır: kart PAN/CVV saklanmaz; mümkünse hosted/token ödeme kullanılır.
7. Ödeme sunucu–sunucu doğrulaması olmadan SUCCESS değildir; UNKNOWN ödeme tekrar otomatik çekilmez.
8. POSTED fiş değiştirilemez/silinemez; yalnız yeni ters kayıt. Onaylı belge içeriği korunur; iptal/iade sürümlü olaydır.
9. KDV, fatura yükümlülüğü, gelir sahibi, kamu/vakıf/döner sermaye statüsü hukuki karardır; yazılım kuralı olarak varsayılan atanmaz.
10. Rapor sayıları gözlem/gerçek geçiş/borç/tahsilat kaynağını ve kanıt kalitesini açık gösterir.
11. Yalnız plaka ile halka açık borç sorgusu yok; kimlik doğrulama ve amaç/süre/kapsam temelli KVKK kontrolü.

## A5 — Kayıt ve kanıt sözlüğü
- Statüler: `CONFIRMED`, `TO_VERIFY`, `UNKNOWN`, `SIMULATED`, `ASSUMED`, `UNSUPPORTED`, `DECISION_REQUIRED`, `BLOCKER`, `DESIGNED`, `NOT_RUN`, `TESTED`, `FIELD_VERIFIED`.
- Kimlikler: `REQ-###`, `NFR-###`, `DEC-###`, `ADR-###`, `RISK-###`, `BLK-###`, `UC-###`, `TC-###`, `EVD-###`, `CR-###`, `G0..G9`.
- `DESIGNED` ≠ `TESTED` ≠ `FIELD_VERIFIED`; her EVD üretim yöntemi, zaman, sürüm, dosya SHA-256 ve inceleyen bilgisi içerir.

## A6 — Aşama teslim sözleşmesi
P00–P33 her aşamada: (1) amaç/girdi, (2) açık karar ve blokajlar, (3) gerçekten değişen dosyalar, (4) gerçek içerik/diff, (5) komutlar, (6) gerçek test/NOT_RUN, (7) REQ→TC→EVD bağlantısı, (8) risk/KVKK/finans/İSG, (9) rollback/etki, (10) kapı önerisi ve imzalar. Aşama tamamlanmadan sonraki aşama otomatik açılmaz.
- Definition of Done uygulama aşamalarında restore/build/format/static analysis, ölçülmüş test kapsamı, güvenlik/contract/DB rollback testleri ve UAT içerir. P00 için **uygulama testi beklentisi yoktur**; yalnız belge/depo doğrulaması yapılabilir.

## A7 — Durum/olay sözleşmeleri
- Ayrı kavramlar: `PlateObservation`, `PassageEvidence`, `ParkingSession`, `FinancialEntitlement`, `PhysicalAccessProvisioning`, `Quote`, `Charge`, `PaymentIntent`, `PaymentTransaction`, `ProviderSettlement`, `Invoice`, `JournalEntry`, `GateAuthorization`, `GateCommand`, `GateAck`, `PhysicalPassage`.
- Event zarfı en az `eventId,eventType,schemaVersion,occurredAtUtc,receivedAtUtc,sourceSystem,correlationId,causationId,idempotencyKey,payloadHash` ve onaylı `tenantId/legalEntityId` kapsamı taşır. Kaynak alan karşılıkları üretici POC sonrası belgelenir.

## A8 — Finansal değişmezler ve sınırlar
- Her mali olay üzerinde onaylı `RevenueOwner, Collector, MerchantOfRecord, SettlementBeneficiary, InvoiceIssuer, AccountingAuthority` rolleri çözülür; **DEC-001 belirsizse canlı mali işlem yok**.
- Çoklu tüzel kişi ödeme paylaştırma izni yoksa yalnız raporlama/simülasyon; yazılım kendi kendine fon transferi yapmaz.
- Posting idempotency: `sourceEventId + postingRuleVersion + legalEntityId`; `POSTED` defterde `Σdebit = Σcredit`, düzeltme ters fiştir.
- Mutabakat türleri ayrı: payment↔charge, payment↔settlement, cash↔shift, invoice↔ledger, ledger↔ERP. Bankada SETTLED teyidi olmadan fon kesinleşmiş sayılmaz.
- Tarife/vergisel politika/sözleşme sürümlü ve tarih-etkin; kapalı dönem fişi geriye dönük sessiz değiştirilmez.

## A9 — Test/kalite ve kapı disiplini
- G0–G9 bağımsız kapılar; imzalı onay ve gerçek EVD olmadan GO yok. 10/10 kalite yalnız 10 boyutta doğrulanmış kanıt ile olur; şu an `NOT_VERIFIED`.
- Kritik/yüksek riskli güvenlik, mali veya İSG BLK varsa üretim `NO-GO`.
- Uygulama aşamalarında hedef genel unit coverage ≥%80; kritik finans/izin yolları branch coverage ≥%90 — **ölçülmemiş test PASS sayılmaz**.
- OWASP ASVS 5.0.0 L2 tasarım hedefidir; doğrulama ayrı yürütülür.

## A10 — Süreklilik/değişiklik yönetimi
- Yeni oturum: `README.md` → `AGENTS.md` → `docs/registries/decisions.csv` → blockers → gate ve EVD → son ADR/CR sırasıyla oku.
- Değişiklikler `CR-###`, mimari değişimler `ADR-###`; mevcut kayıt silinmez, sürümlü kapatılır. `DEC-001` veya mevcut üretici otorite sınırlarını sessiz değiştirip yeniden yazma.
- Üretim komutları başlangıçta kapalı kalır. Finansal sonuç/cihaz başarısı simüle edilip gerçekmiş gibi gösterilemez.
