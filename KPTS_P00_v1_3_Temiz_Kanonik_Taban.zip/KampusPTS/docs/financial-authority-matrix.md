# Finansal Yetki ve Çoklu Tahsilat Tasarımı — P00

> **Hukuki hüküm değil, yetki modeli tasarımıdır.** Tüm A/B/C/D seçenekleri korunur. Hangisinin gerçekleşeceği `DEC-001` ile kararlaştırılacak; o zamana kadar canlı mali kayıt ve belge gönderimi `OFF`.

## İş/varlık sözlüğü
| Kavram | Yetki kaynağı | Değişmez kontrol |
|---|---|---|
| `RevenueOwner` | Mali İşler + Hukuk; hizmet sözleşmesi | Gelir kime aittir; kurum/işletmeci kapsamlı ve geçerlilik tarihli |
| `Collector` | Hukuki tahsil yetkisi / sözleşme | Tahsilat başlatmaya ve makbuz sürecine yetkili kişi/kurum |
| `MerchantOfRecord` | Banka/PSP üye işyeri sözleşmesi | PSP işleminde esas merchant; `Collector` ile eşit olmak zorunda değil |
| `SettlementBeneficiary` | Banka/PSP fon akışı sözleşmesi | Tahsilatın hangi hesaba intikal ettiği; keyfî split yasak |
| `InvoiceIssuer` | Vergi/Hukuk + Mali İşler | e-Belgeyi hangi mükellefin düzenlediği |
| `AccountingAuthority` | İlgili ERP/defter sahibi | PTS alt defteri ≠ yetkili nihai muhasebe kaydı |
| `TaxPolicyOwner` | Yetkili Mali İşler/vergi danışmanı | KDV/istisna ve belge zamanını versiyonlar, uygulama icat etmez |
| `PhysicalAccessOwner` | GV-ASManager için Güvenlik | Mali `ALLOW` erişim onayı değildir |
| `GateExecutionOwner` | `DEC-008` ile belirlenecek | Fiziksel kumanda başlangıç `UNKNOWN` |

## Alternatif A/B/C/D örnekleri
| Model | Gelir sahibi | Merchant/beneficiary | Fatura ve ERP |
|---|---|---|---|
| A Üniversite | Hukuken yetkili üniversite birimi/kurumu | Sözleşmeli hesap; ayrıntı `DEC-031` | Vergi profili/ERP onayı ayrı |
| B Döner sermaye | Yetkili döner sermaye işletmesi | İşletme/vekil merchant; sözleşme şart | Vergi statüsü ve ayrı ERP/maliyet merkezi |
| C Özel işletmeci | Sözleşmede gelir sahibi olarak belirlenen taraf | İşletmeci veya vekil; belge ve sözleşme gerekir | Vergi profili + işletmeci ERP'si |
| D Çoklu kurum | Hizmet + kampüs + sözleşme + dönem bazında | İşlem bazlı onaylı yönlendirme; split ancak yasal PSP ürünü | Her belgede tek onaylı issuer ve yönlenen ilgili ERP |

## Sorumluluk matrisi
| İşlem | Karar/otorite | PTS işlevi | Ön şart |
|---|---|---|---|
| Ücret alınabilen hizmet | Sponsor + Hukuk | Hizmet kuralı | `DEC-027` |
| Tarife yayımı | Yetkili yönetim + Mali İşler | Kural uygulaması, çift onay | `DEC-007`, `DEC-017` |
| Merchant/banka hesabı | Mali İşler + banka/PSP | Onaylı yapılandırma | `DEC-003`,`DEC-031` |
| Ücret/tahakkuk | Onaylı tarife ve gelir sahibi | `Quote`→`Charge` | Onaylı geçiş + legalEntity çözümü |
| Ödeme | Banka/PSP | `PaymentIntent` ve doğrulanmış `PaymentTransaction` | Signed callback/S2S, idempotency |
| Fonun bankaya geçmesi | Banka/PSP | `ProviderSettlement` eşleme | Banka mutabakatı |
| e-Fatura/e-Arşiv | Issuer + yetkili entegratör | Kural kontrollü `Invoice` | `DEC-002`,`DEC-004`,`DEC-028`,`DEC-030` |
| İade/chargeback | Mali İşler + PSP | Yeni reversal/izin izleri | `DEC-012`,`DEC-023`, dört göz |
| Kapanış ve yevmiye | Mali İşler / ERP sahibi | Balanced alt defter + ihracat | `DEC-005`,`DEC-022` |
| Fiziksel bariyer | Güvenlik/İSG + teyitli kumanda sahibi | Başlangıçta simüle karar | `DEC-008`, saha kanıtı |

## İşlem bağlamı ve zaman
Bütün mali nesnelerde en az: `tenantId`, `campusId`, `serviceId`, `contractVersionId`, `legalEntityId`, `revenueOwnerId`, `collectorId`, `merchantConfigVersionId`, `settlementBeneficiaryId`, `invoiceIssuerId`, `accountingBookId`, `policyEffectiveAtUtc`, `correlationId`, `idempotencyKey` (uygulanabilen nesnelerde). Bu öneri kesin veritabanı şeması değildir.

**Önemli:** Her Charge'ın tek hesap yetki yolu olmalıdır; sözleşme değişikliği geçmiş Charge'ı veya gönderilmiş Invoice'u yeni tüzel kişiliğe sessizce taşıyamaz. Eski borçlar tarihsel sözleşmeye bağlı kalır; taşıma gerektiğinde kurum onaylı düzeltme veya tasfiye prosedürü uygulanır (`REQ-039`). Aynı ücretin birden çok paydaş arasında paylaştırılması ayrı sağlayıcı sözleşmesi ve izin incelemesi gerektirir (`DEC-026`).

## NO-GO kuralları
- Gelir sahibi `UNKNOWN` → canlı `Charge`, gerçek ödeme veya e-belge **yasak**.
- `InvoiceIssuer` veya vergi kuralı doğrulanmamış → gerçek e-belge **yasak**.
- Merchant ile settlement hesabı sözleşmesiz → gerçek ödeme **yasak**.
- PSP capture veya banka settlement belirsiz → `SETTLED` raporu **yasak**.
- Fiziksel geçiş kontrol otoritesi teyitsiz → bariyer komutu **yasak**.

## Yetki/SoD
Tarife yayımlayan, hesap eşleyen, muafiyet oluşturan ve iade başlatan kullanıcı kendi kritik işlemini onaylayamaz. Tenant/legalEntity/campus/service kapsamını aşan erişim engellenir; tüm kritik kararlar gerekçe, kimlik ve eski/yeni sürümle kayıtlanır. Tutara göre onay limitleri `DEC-017` ile belirlenecek.
