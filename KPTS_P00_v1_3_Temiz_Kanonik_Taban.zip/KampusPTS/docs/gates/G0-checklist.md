# G0 — P00 İmza Kontrol Formu

**Durum:** `NOT_APPROVED` — otomatik PASS veya GO yok.

| ID | Kanıt/ölçüt | Hazırlanan girdi | Kurumsal durum |
|---|---|---|---|
| G0-01 | Sponsor ve süreç sorumluları atanmış | Charter rol tablosu, kişi yok | NOT_VERIFIED |
| G0-02 | A1–A10/K-01–K-12 imzalanmış | `AGENTS.md`, charter | NOT_VERIFIED |
| G0-03 | G0–G9 bağımlılık/onay otoriteleri kabul | `docs/governance/gates.md` | NOT_VERIFIED |
| G0-04 | DEC/REQ/ADR/RISK/BLK/TC/EVD/CR şablonları | `docs/templates/` | NOT_VERIFIED |
| G0-05 | Canlı gate/payment/e-belge başlangıç kapalı | `config/features.example.json` | NOT_VERIFIED (tasarım dosyası var) |
| G0-06 | Açık mali DEC→BLK→Gate etkisi görünür | `docs/registries/` | NOT_VERIFIED |
| G0-07 | Kurumsal sponsor G0 imzası | İmza alanı aşağıda | NOT_VERIFIED |

**Öneri:** `CONDITIONAL/NO-GO` inceleme; sponsor imzasına kadar G0=NOT_APPROVED. P00 dosyalarının varlığı taslak hazırlığıdır.

Sponsor: __________  Tarih: __________  Karar: __________  
BİDB: __________  Mali İşler: __________  Güvenlik/İSG: __________  
Onay tutanak/ref: __________  Açık şartlar: __________
