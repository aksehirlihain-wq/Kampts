# P00 Aşama Teslim Formu — Gerçek Durum

1. **Amaç / girdi:** v2.1 proje kuralları ve 20.10.2026 başlangıç belgesi. Gelir modeli A/B/C/D ve `DEC-001` çözülmemiştir.
2. **Açık DEC/BLK:** `docs/registries/decisions.csv` / `blockers.csv`; canlı mali ve saha yetkileri blokaj altındadır.
3. **Değişen dosyalar:** ZIP içindeki dosyalar; `manifest.sha256` kanıtı.
4. **Gerçek içerik:** AGENTS.md; charter; finans matrisi; ADR; kayıt/şablonlar; temel araçlar; herhangi uygulama kodu yok.
5. **Komutlar:** `python3 tools/validate_p00.py`; `python3 -m unittest discover -s tests -v`; `python3 tools/build_manifest.py`.
6. **Testler:** Yalnız dosya, karar ID ve referans bütünlüğü testleri; çalıştırma günlük özeti `validation-report.txt`. `.NET restore/build` ve cihaz/ödeme/belge testleri `NOT_RUN`.
7. **Kabul/izleme:** `requirements.csv`, `nfr.csv`, `traceability.csv`, `test-cases.csv`; TC senaryoları `NOT_RUN`.
8. **Risk/etki:** `risks.csv`, `blockers.csv`, `docs/governance/security-controls.md`.
9. **Geri alma:** P00 dosya değişiklikleri Git commit/revert; canlı cihaz, PSP veya ERP üzerinde etki yok.
10. **Kapı önerisi:** `REVIEW_REQUIRED` / G0 `NOT_APPROVED`; sponsor ve paydaşların imzaları gereklidir. P01 otomatik başlamaz.
