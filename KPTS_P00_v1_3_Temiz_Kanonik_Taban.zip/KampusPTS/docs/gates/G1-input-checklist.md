# G1 — P01–P04 İçin Ön Kontroller (P00 Çıktısına Dahil Değil)

| Kontrol | Durum |
|---|---|
| G1-01 Gelir/kurum seçenekleri; hukuk karar sahipleri | NOT_VERIFIED |
| G1-02 Kampüs/şerit/kamera/controller/sensör envanteri | NOT_VERIFIED |
| G1-03 Üretici Webhook/POST kanıtı veya açık BLK | NOT_VERIFIED |
| G1-04 Geçiş kanıtı, gate sahibi, offline/İSG | NOT_VERIFIED |
| G1-05 Aktör senaryoları + RACI | NOT_VERIFIED |
| G1-06 REQ/NFR ve 60+ taslak BDD/izlenebilirlik | NOT_VERIFIED |
| G1-07 Mali/vergisel e-belge/ERP/PSP kararları ve sahipleri | NOT_VERIFIED |
| G1-08 KVKK veri işleme envanteri | NOT_VERIFIED |
| G1-09 Pilot NFR/SLA/RPO/RTO önerisi | NOT_VERIFIED |
| G1-10 Sponsor+Mali İşler+BİDB+Güvenlik kararı | NOT_VERIFIED |

**Açıklama:** 40 REQ ve 16 NFR önceki başlangıç belgesinden içe alınmıştır; 60+ BDD senaryosu henüz yazılmamış ve test edilmemiştir. Buradaki sıfır kanıt, gerçek çalıştırma eksikliği anlamındadır.
