# G0–G9 Bağımsız Onay Kapıları

| Kapı | Aşamalar | Gerekli kanıt/karar | Önerilen imza otoritesi |
|---|---|---|---|
| G0 | P00 | AGENTS, charter, şablonlar, repo standardı, karar/blokaj/kapsam, sponsor onayı | Sponsor; görüş BİDB+Mali İşler |
| G1 | P01–P04 | Keşif/SRS, gerçek üretici kanıtı veya BLK, mali-hukuki kararlar ve sahipleri | Sponsor+BİDB+Güvenlik+Mali İşler |
| G2 | P05–P06 | C4/ADR, threat model, KVKK ve ASVS güvenlik tasarımı | BİDB+Bilgi Güvenliği+Mali İşler+Hukuk |
| G3 | P07–P10 | Derleme/CI, IAM/SoD ve veritabanı migration gerçek test kanıtları | BİDB+Bilgi Güvenliği |
| G4 | P11–P15 | Mock kanıtlı olay→oturum→hak/abonelik; replay | BİDB+Güvenlik+İşletme |
| G5 | P16–P19 | Tarife golden-cases, PSP sandbox S2S, çift ödeme engeli | Mali İşler+İşletme |
| G6 | P20–P22 | Dengeli defter, sandbox belge/ERP, dönem kapama kontrolleri | Mali İşler+İç Denetim |
| G7 | P23–P28 | Simülatör gate, operatör paneli, portal/kiosk ve UAT | İşletme+BİDB+Güvenlik |
| G8 | P29–P31 | Güvenlik ve yük/DR testleri, uygulama E2E kanıtları | BİDB+Bilgi Güvenliği+QA |
| G9 | P32–P33 | Gerçek pilot, mali ve cihaz onayı, İSG, eğitim ve geri dönüş planı | Sponsor+Mali İşler+BİDB+Güvenlik+İSG |

**Durum sözlüğü:** `NOT_STARTED`, `PREPARED`, `IN_REVIEW`, `GO`, `CONDITIONAL_GO`, `NO_GO`. `GO` gerçek imza/EVD ister; repo validator sonucu kapı onayı yerine geçmez. `CONDITIONAL_GO` canlı işlem blokajlarını geçersiz kılamaz. P00 bu teslimde `PREPARED`; G0 `IN_REVIEW` bile kurum incelemesi başlamadan atanamaz.

**NO-GO:** İSG riski, kanıtsız gerçek bariyer komutu, belirsiz gelir sahibiyle canlı tahsilat, yetkisiz kişisel bilgi yayını, kritik/yüksek güvenlik açığı.
