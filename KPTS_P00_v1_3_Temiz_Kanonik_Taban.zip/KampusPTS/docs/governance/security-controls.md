# P00 Güvenlik, KVKK ve İSG Kontrol İlkeleri

- OIDC + MFA + RBAC/ABAC; tenant/legalEntity/campus/service kapsamı. Yetki kontrolü sunucu tarafında zorunludur.
- Plaka/görüntü/kimlik/ödeme bilgileri veri sınıfı ve amaçla eşlenir. Saklama-imha süreleri bilinmiyorsa uydurulmaz (`DEC-011`, `DEC-016`).
- Portalda sadece plaka ile borç görüntüleme yok; ikinci faktör ve kullanıcıyla güvenli ilişkilendirme gerekir. KVKK Kurulunun 2023/924 kararı değerlendirmeye alınır.
- PAN/CVV saklanmaz. Parola, API sırrı, PSP token'ı ve entegratör özel anahtarı örnek dosyalara koyulmaz.
- TLS, gizli anahtar yönetimi, yedek şifreleme, audit ve hassas alan maskeleme zorunlu tasarım koşuludur.
- İade ve tarife onayı için SoD/çift göz; eşik tutarlar `DEC-017`.
- CANLI GATE, ÖDEME VE E-BELGE bayrakları `false`; G0 onayı bunları açma izni değildir.
- İSG hayat güvenliği sistemleri bağımsız; PTS arızası personel giriş/geçişinin ve acil tahliyenin korunmuş fiziki altyapısını bozmaz.
- OWASP ASVS 5.0.0 L2 **test hedefi**; mevcut aşama için uyumluluk kanıtı yok.

Resmî dayanak/doğrulama adresleri: `docs/sources.md` (hukuki yorum kurum uzmanları tarafından ayrıca onaylanır).
