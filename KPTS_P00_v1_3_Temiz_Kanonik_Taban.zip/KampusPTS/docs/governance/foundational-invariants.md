# P00 — K-01–K-12 Bağlayıcı Mimari Değişmezler

**Durum:** `PROPOSED / NOT_APPROVED` — bu maddeler P00 tasarımının teknik yasak/ilkeleridir.

| Kural | Değişmez | Zorunlu kanıt/uygulama |
|---|---|---|
| K-01 | Fiziksel ve mali otorite ayrılığı | GV-ASManager personel erişimi; PTS mali hak; ERP nihai muhasebe; cross-DB write yok |
| K-02 | Marka bağımsızlığı | Belgeli PTS üretici adaptörleri; bilinmeyen API alanları `UNKNOWN` |
| K-03 | Gözlem ve gerçek geçiş farklıdır | PlateObservation ≠ PassageEvidence ≠ GateAck; doğrulanmamış plaka oturum açmaz |
| K-04 | CAPTURED, SETTLED değildir | Quote ≠ Charge ≠ PaymentTransaction ≠ Invoice ≠ JournalEntry; banka mutabakatı ayrı |
| K-05 | Modül veri sahipliği | Modül dışı doğrudan tablo/şema yazımı yok; API/events |
| K-06 | Zaman/sürüm değişmezliği | Tarifeler, sözleşmeler, haklar tarih-etkin sürümlü ve denetlenebilir |
| K-07 | Kesin finansal kayıt silinmez | Immutable POSTED journal / belge; ters fiş ve gerekçe gerekir |
| K-08 | Fiziksel can güvenliği önde gelir | Yangın tahliyesi, anti-sıkışma, fotosel bağımsızdır |
| K-09 | KVKK asgari veri | İşleme amacı, erişim, maskeleme, saklama/imha ve audit |
| K-10 | Üretimde real ops default kapalı | Gate, ödeme ve e-belge `false`; çift onay + kill switch |
| K-11 | Kritik mali işlemde görev ayrılığı | İade/tarife/hesap değişikliği/muafiyet dört göz |
| K-12 | Test ve kanıt doğruluğu | Gerçek testi olmayan kayda PASS değil `NOT_RUN` |

**Mimari zorunluluk:** `UNKNOWN` ≠ `FALSE`; `AI` ≠ `InstitutionalAuthority`; `FactOwner` = `CommandOwner` = `DomainEventOwner` kavramları mevcut yetki alanı için tasarım ölçütüdür. Kanıt sahibi değilken başka sisteme değişiklik yazılmaz. Bu alanların gerçek kurumsal sahipleri P01–P04 çalıştaylarında netleştirilir.
