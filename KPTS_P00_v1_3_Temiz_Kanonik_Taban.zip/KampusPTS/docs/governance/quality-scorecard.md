# P00 Kalite Hedef Kartı (10/10 Hedefi — Mevcut Skor Yok)

**Gerçek durum:** Her boyutta `NOT_VERIFIED`; 10/10 veya üretim uygunluğu iddiası yapılmaz.

| ID | Boyut | Gerçek kanıt örnekleri | Mevcut durum |
|---|---|---|---|
| Q01 | Yönetişim | Charter imzası, CR/DEC sahibi, G kapısı tutanağı | NOT_VERIFIED |
| Q02 | Mimari | ADR onayı, modül sınırı, rollback testleri | NOT_VERIFIED |
| Q03 | Üretici PTS | Gerçek Webhook/POST payload, firmware ve olay replay | NOT_VERIFIED |
| Q04 | Fiziksel güvenlik | Passage sensör kanıtı, emniyet ve gate sahibinin testi | NOT_VERIFIED |
| Q05 | Ücret/finans | Tarife golden-case, çift ödeme engeli, settlement | NOT_VERIFIED |
| Q06 | Güvenlik/KVKK | ASVS 5 L2, yetki, veri maskeleme, sızma testi | NOT_VERIFIED |
| Q07 | IAM/Audit | MFA, dört göz, audit tamlığı ve gözden geçirme | NOT_VERIFIED |
| Q08 | Test | E2E/negatif/yük/sürüm testi ve ölçülen coverage | NOT_VERIFIED |
| Q09 | Operasyon | Yedek-geri yükleme, RPO/RTO, alarm prosedürü | NOT_VERIFIED |
| Q10 | İşlev/UX | Türkçe erişilebilir UI, finans/gişe UAT | NOT_VERIFIED |

Skor yalnız imzalı, tekrar üretilebilir ve kayıtlı EVD ile yükselir. CI'daki yapısal kontrol PASS sonucu bu kartı değiştirmez. Kritik mali/İSG/KVKK BLK varlığında G9 `NO-GO`.
