# Finansal İş Akışlarının Kanonik Kavramları

`PlateObservation` → (onaylı eşleştirme) → `PassageEvidence` → `ParkingSession` → `Quote` → `Charge` → `PaymentIntent` → `PaymentTransaction` → `Invoice` / `LedgerEntry` → `ERP export` / `ProviderSettlement`.

Bu görsel bir zorunlu tek sıra değildir: fatura zamanı, capture ve settlement sırası sözleşme ve mevzuata göre farklı olabilir. Her nesnenin durumu ayrı tutulur.

| Nesne | Değişmez |
|---|---|
| PlateObservation | Plaka görüldü; geçişin ispatı değildir |
| PassageEvidence | Sensör/controller veya doğrulanmış kaynak, kalite ve kanıt referansı |
| ParkingSession | Belirlenmiş politikalarda tek aktif oturum; belirsiz olay incelemeye gider |
| Quote | Süresi sınırlı fiyat hesaplaması; kesin alacak değildir |
| Charge | Onaylı hizmet, tüzel kişilik ve tarifeye ait borç/alacak olayı |
| PaymentIntent | Değişebilir başvuru durumu; tek başına tahsilat değil |
| PaymentTransaction | Doğrulanmış finans olayı append-only; `UNKNOWN` otomatik yeniden çekilmez |
| ProviderSettlement | Banka/PSP fon intikali kanıtı; CAPTURED ile ayrı |
| Invoice | Draft/sent/accepted/rejected/cancelled durum geçmişi; yanlış issuer gönderilemez |
| JournalEntry | POSTED dengeli ve immutable; hata yeni reversal ile düzeltilir |
| PhysicalAccessProvisioning | Finansal abonelikten bağımsız `VERIFIED_ACTIVE` zorunluluğu |
| GateDecision / GateAck | İzin ve gerçek cihaz ACK ayrıdır, fiziksel geçiş ayrıca kanıtlanır |

**Örnek posting idempotency:** `sourceEventId|postingRuleVersion|legalEntityId`. Aynı kaynak olayı iki kez gelirse ikinci ledger posting yok. Ancak provider'in kendisinin yeniden gönderdiği veya yeni işlem ürettiği durumlarda yeniden deneme semantiği P05+ testlerle doğrulanmalıdır.
