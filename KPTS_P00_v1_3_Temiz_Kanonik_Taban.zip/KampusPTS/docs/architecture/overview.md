# P00 Referans Yazılım Mimarisi

## Katmanlar
`Api` (REST/OpenAPI) ve `Workers` (inbox/outbox, entegrasyon) → modül `Application` use-case'leri → saf `Domain`; `Infrastructure` ise uygulama portlarını uygular. `SharedKernel` yalnız teknik ortak primitive içerir. Tüm modüller aynı dağıtım biriminde başlayabilir; bağımsız DB sahipliği korunur.

## Modüller ve veri sahipliği
| Bounded context | Sahip olduğu veri/kararlar |
|---|---|
| Integrations | `RawDeviceEvent`, schema mapping, adapter diagnostics |
| Sessions | `PassageEvidence`, `ParkingSession` (observation değil) |
| Entitlements/Subscriptions | Mali hak, plan, abonelik ve fiziksel provisioning teyit durumu |
| Tariffs/Quotes | Sürümlü tarife, hesaplama kuralları, geçici Quote |
| Payments | Charge'a ödeme yönelimi, PaymentIntent/Transaction; PSP kanıtı |
| Invoicing | Belge düzenleyici profili, Invoice/InvoiceStatus |
| Ledger | Dengeli JournalEntry ve ters kayıt |
| Reconciliation | Banka, PSP, ERP ve belge fark raporları |
| Gate | GateDecision, GateAuthorization/Command/Ack durumları; canlı command OFF |
| IdentityAccess/Audit | RBAC/ABAC/SoD ve append-only denetim izi |
| Reporting/Portal | Onaylı rapor projesiyonu, güvenli sorgu ve self-service |

## Kurum modelinin sınırları
`Tenant` (ürünü kullanan bağımsız kurum), `LegalEntity` (vergisel/mali taraf), `Campus`, `ParkingArea`, `Lane`, `Service`, `ContractVersion` farklı yapılardır. Tek tenant birden çok legal entity barındırabilir. Asgari erişim/partition filtresi `tenantId` ve nesnenin ilgili `legalEntityId` kapsamıyla uygulanır. Cross-tenant veri akışı açık sözleşme olmadan yok.

## Tutarlılık ve zaman
- Transactional outbox ve durable inbox; idempotent tüketici; sürüm ve payloadHash.
- UTC kayıt, gösterimde Europe/Istanbul; tarihsel tarife ve sözleşme kararları bitemporal ihtiyaç açısından ayrıca ADR ile değerlendirilir.
- Sadece REST/Webhook/SDK-adaptör portları; gerçek endpoint, payload ve cihaz davranışı P02 kanıt gelene kadar `UNKNOWN`.
- Veri tabanında schema per module; bir modül başka modülün veritabanı tablosuna yazamaz.

## Saha ayrımı
ASManager fiziksel personel yetkilerini korur. PTS `FinancialEntitlement` finansını tutar; fiziksel `PhysicalAccessProvisioning` ayrıca teyit edilir. Ziyaretçi için PTS mali çıkış önerir; fiziksel gate execution otoritesi bilinmemektedir.

## Kalite
.NET build/CI/DB integration ve otomatik uygulama testleri P07 sonrası planlanır. P00'da yalnız depo içerik ve kayıtlara yönelik validator vardır. Güvenlik tasarım hedefi OWASP ASVS 5.0.0 L2; gerçek doğrulama ayrı kapılarda.
