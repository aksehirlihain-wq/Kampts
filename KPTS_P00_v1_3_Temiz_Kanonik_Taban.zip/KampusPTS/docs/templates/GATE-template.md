# GATE-### — Kayıt Şablonu

**Kimlik:** GATE-___  
**Statü:** NOT_STARTED  
**Son değişiklik UTC:** UNKNOWN  
**Bağlantılar:** __________

## 1. Önkoşullar
UNKNOWN

## 2. Kanıt listesi
UNKNOWN

## 3. Açık DEC/BLK
UNKNOWN

## 4. Ölçüm ve skor
UNKNOWN

## 5. Finans/KVKK/İSG kontrolü
UNKNOWN

## 6. Onaylayan roller ve tarihler
UNKNOWN

## 7. GO/NO-GO/CONDITIONAL_GO gerekçesi
UNKNOWN

**UYARI:** Gerçek onay/test/kanıt yoksa PASS yazmayın.
