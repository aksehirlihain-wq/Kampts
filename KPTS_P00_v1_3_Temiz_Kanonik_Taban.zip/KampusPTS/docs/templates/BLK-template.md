# BLK-### — Kayıt Şablonu

**Kimlik:** BLK-___  
**Statü:** NOT_STARTED  
**Son değişiklik UTC:** UNKNOWN  
**Bağlantılar:** __________

## 1. Ön koşul/kanıt eksikliği
UNKNOWN

## 2. Hangi canlı işlem engelleniyor?
UNKNOWN

## 3. Etki G kapısı
UNKNOWN

## 4. Bağlı DEC/REQ
UNKNOWN

## 5. Çözüm görevlisi
UNKNOWN

## 6. EVD beklenen
UNKNOWN

## 7. Kapanış imzası
UNKNOWN

## 8. OPEN/CLOSED
UNKNOWN

**UYARI:** Gerçek onay/test/kanıt yoksa PASS yazmayın.
