# NFR-### — Kayıt Şablonu

**Kimlik:** NFR-___  
**Statü:** NOT_STARTED  
**Son değişiklik UTC:** UNKNOWN  
**Bağlantılar:** __________

## 1. Kalite/güvenlik alanı
UNKNOWN

## 2. Ölçülebilir eşik ve test yöntemi
UNKNOWN

## 3. Mevcut değer UNKNOWN
UNKNOWN

## 4. Bütçe/etki
UNKNOWN

## 5. Sahip
UNKNOWN

## 6. TC
UNKNOWN

## 7. EVD
UNKNOWN

## 8. Kapı
UNKNOWN

**UYARI:** Gerçek onay/test/kanıt yoksa PASS yazmayın.
