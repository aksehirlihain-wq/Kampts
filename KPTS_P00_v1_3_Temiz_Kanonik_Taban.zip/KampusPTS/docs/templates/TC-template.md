# TC-### — Kayıt Şablonu

**Kimlik:** TC-___  
**Statü:** NOT_STARTED  
**Son değişiklik UTC:** UNKNOWN  
**Bağlantılar:** __________

## 1. Test amacı
UNKNOWN

## 2. Başlangıç koşulları
UNKNOWN

## 3. Given
UNKNOWN

## 4. When
UNKNOWN

## 5. Then
UNKNOWN

## 6. Negatif dal
UNKNOWN

## 7. Gerekli ortam
UNKNOWN

## 8. Test komutu
UNKNOWN

## 9. Beklenen EVD
UNKNOWN

## 10. Durum NOT_RUN
UNKNOWN

**UYARI:** Gerçek onay/test/kanıt yoksa PASS yazmayın.
