# ADR-### — Kayıt Şablonu

**Kimlik:** ADR-___  
**Statü:** NOT_STARTED  
**Son değişiklik UTC:** UNKNOWN  
**Bağlantılar:** __________

## 1. Mimari karar
UNKNOWN

## 2. Bağlam
UNKNOWN

## 3. Alternatifler
UNKNOWN

## 4. Karar/gerekçe
UNKNOWN

## 5. Güvenlik/finans/İSG etkisi
UNKNOWN

## 6. Yan etkiler
UNKNOWN

## 7. Test/geri alma
UNKNOWN

## 8. Kurum imzası
UNKNOWN

## 9. PROPOSED/ACCEPTED/SUPERSEDED
UNKNOWN

**UYARI:** Gerçek onay/test/kanıt yoksa PASS yazmayın.
