# EVD-### — Kayıt Şablonu

**Kimlik:** EVD-___  
**Statü:** NOT_STARTED  
**Son değişiklik UTC:** UNKNOWN  
**Bağlantılar:** __________

## 1. Gerçek kanıt tipi
UNKNOWN

## 2. Kaynak/sistem ve sürüm
UNKNOWN

## 3. Çalıştıran + inceleyen
UNKNOWN

## 4. UTC tarih
UNKNOWN

## 5. Komut/adımlar
UNKNOWN

## 6. Dosya adları
UNKNOWN

## 7. SHA256
UNKNOWN

## 8. Sonuç PASS/FAIL/NOT_RUN
UNKNOWN

## 9. Bağlı REQ/TC/DEC/Gate
UNKNOWN

## 10. Kişisel veri maskeleme kontrolü
UNKNOWN

**UYARI:** Gerçek onay/test/kanıt yoksa PASS yazmayın.
