# CR-### — Kayıt Şablonu

**Kimlik:** CR-___  
**Statü:** NOT_STARTED  
**Son değişiklik UTC:** UNKNOWN  
**Bağlantılar:** __________

## 1. Talep sahibi
UNKNOWN

## 2. İş kapsamı
UNKNOWN

## 3. Hangi REQ/DEC/ADR değişecek?
UNKNOWN

## 4. Alternatifler
UNKNOWN

## 5. Risk ve uyumluluk etkisi
UNKNOWN

## 6. Test/EVD
UNKNOWN

## 7. Rollback
UNKNOWN

## 8. Sponsor imzası
UNKNOWN

## 9. Durum
UNKNOWN

**UYARI:** Gerçek onay/test/kanıt yoksa PASS yazmayın.
