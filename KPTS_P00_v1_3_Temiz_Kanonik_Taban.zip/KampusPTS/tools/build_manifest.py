#!/usr/bin/env python3
"""Rebuild SHA-256 file manifest (exclude self-reference and generated zip)."""
from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parents[1]
files=sorted((p for p in ROOT.rglob('*') if p.is_file() and p.name not in ('manifest.sha256',) and '__pycache__' not in p.parts and '.git' not in p.parts), key=lambda p: str(p.relative_to(ROOT)))
lines=[f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT).as_posix()}' for p in files]
(ROOT/'manifest.sha256').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(f'Wrote manifest.sha256 for {len(files)} files')
