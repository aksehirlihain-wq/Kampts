#!/usr/bin/env python3
"""Validate P00 file/registry internal consistency. This does NOT test a real app or any device."""
from pathlib import Path
import csv, json, sys, re, xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
class ValidationError(Exception): pass

def read_csv(name):
    with (ROOT/'docs'/'registries'/name).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def ensure(x,msg):
    if not x: raise ValidationError(msg)

def unique_ids(rows,pattern,kind):
    ids=[r['id'] for r in rows]
    ensure(len(ids)==len(set(ids)),f'duplicate {kind} ids')
    for v in ids: ensure(bool(re.fullmatch(pattern,v)),f'invalid {kind} ID: {v}')
    return set(ids)

def validate():
    required=['AGENTS.md','README.md','Directory.Build.props','.editorconfig','docs/charter.md',
              'docs/financial-authority-matrix.md','docs/governance/foundational-invariants.md',
              'docs/governance/quality-scorecard.md','docs/gates/G0-checklist.md',
              'config/features.example.json','docs/registries/requirements.csv',
              'docs/registries/nfr.csv','docs/registries/decisions.csv',
              'docs/registries/blockers.csv','docs/registries/risks.csv',
              'docs/registries/test-cases.csv','docs/registries/traceability.csv']
    for n in required: ensure((ROOT/n).is_file(),f'missing {n}')
    for n in ['DEC','REQ','NFR','RISK','BLK','TC','EVD','ADR','CR','GATE','BR']:
        ensure((ROOT/f'docs/templates/{n}-template.md').is_file(),f'missing template {n}')
    req=read_csv('requirements.csv');nfr=read_csv('nfr.csv');dec=read_csv('decisions.csv')
    risk=read_csv('risks.csv'); blk=read_csv('blockers.csv'); tc=read_csv('test-cases.csv'); trace=read_csv('traceability.csv'); gates=read_csv('gates.csv')
    req_ids=unique_ids(req,r'REQ-\d{3}','REQ'); nfr_ids=unique_ids(nfr,r'NFR-\d{3}','NFR')
    dec_ids=unique_ids(dec,r'DEC-\d{3}','DEC');risk_ids=unique_ids(risk,r'RISK-\d{3}','RISK')
    unique_ids(blk,r'BLK-\d{3}','BLK');tc_ids=unique_ids(tc,r'TC-\d{3}','TC')
    gate_ids=unique_ids(gates,r'G[0-9]','Gate')
    ensure(req_ids=={f'REQ-{i:03d}' for i in range(1,41)},'requirement IDs mismatch')
    ensure(nfr_ids=={f'NFR-{i:03d}' for i in range(1,17)},'NFR IDs mismatch')
    ensure(dec_ids=={f'DEC-{i:03d}' for i in range(1,32)},'DEC IDs mismatch')
    ensure(risk_ids=={f'RISK-{i:03d}' for i in range(1,16)},'RISK IDs mismatch')
    ensure(gate_ids=={f'G{i}' for i in range(10)},'Gate IDs mismatch')
    for d in dec:
        ensure(d['status']=='DECISION_REQUIRED',f'non-pending legal decision: {d["id"]}')
        ensure(d['actual_owner']=='TO_ASSIGN' and d['due_date']=='TBD',f'false assigned DEC: {d["id"]}')
    for b in blk:
        ensure(b['status']=='OPEN',f'unsupported closed blocker: {b["id"]}')
        for x in filter(None,b['decision_ids'].split(';')):ensure(x in dec_ids,f'unknown {x} in {b["id"]}')
        for x in b['requirement_ids'].split(';'):ensure(x in req_ids,f'unknown {x} in {b["id"]}')
        for x in b['gates'].split('/'): ensure(x in gate_ids,f'unknown gate {x} in {b["id"]}')
    for t in tc:
        ensure(t['status']=='NOT_RUN' and t['evidence']=='NONE',f'false TC proof {t["id"]}')
        for x in t['requirement_ids'].split(';'):ensure(x in req_ids,f'unknown TC ref {x}')
    trace_ids={t['requirement_id'] for t in trace}
    ensure(len(trace_ids)==len(trace)==len(req)+len(nfr),'traceability duplicates/missing')
    ensure(trace_ids==req_ids|nfr_ids,'traceability incomplete')
    for t in trace:
        for x in t['test_case_ids'].split(';'):
            ensure(x=='NOT_YET_DEFINED' or x in tc_ids,f'unknown TC in traceability: {x}')
        ensure(t['evidence_ids']=='NONE','P00 cannot claim EVD')
    for g in gates:
        ensure(g['status']==('NOT_APPROVED' if g['id']=='G0' else 'NOT_STARTED'),'unexpected gate status')
    json.loads((ROOT/'docs/architecture/event-envelope.schema.json').read_text(encoding='utf-8'))
    cfg=json.loads((ROOT/'config/features.example.json').read_text(encoding='utf-8'))
    ensure(all(v is False for v in cfg['features'].values()),'real feature flag must be false')
    ET.parse(ROOT/'Directory.Build.props')
    return {'requirements':len(req),'nfr':len(nfr),'decisions':len(dec),'risks':len(risk),
            'blockers':len(blk),'tests_designed_not_run':len(tc),'traceability':len(trace),'gates_not_approved':len(gates)}

if __name__=='__main__':
    try:
        result=validate();print('PASS: P00 structural checks only — no runtime/vendor/finance test performed.')
        for k,v in result.items(): print(f'  {k}: {v}')
    except (ValidationError,Exception) as e:
        print(f'FAIL: {e}',file=sys.stderr);sys.exit(1)
