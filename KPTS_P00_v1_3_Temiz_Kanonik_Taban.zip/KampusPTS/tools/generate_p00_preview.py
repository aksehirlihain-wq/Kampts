#!/usr/bin/env python3
"""Generate PREVIEW_ONLY snapshot from P00 canonical CSV/Markdown. No backend or external API."""
import csv,hashlib,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
WEB=ROOT.parent

def rows(name):
  with (ROOT/'docs/registries'/name).open(encoding='utf-8-sig',newline='') as f:
    return list(csv.DictReader(f))

def parse_md_table(relative,code_pattern):
  result=[]
  for ln in (ROOT/relative).read_text(encoding='utf-8').splitlines():
    if not ln.startswith('|'): continue
    parts=[x.strip() for x in ln.split('|')[1:-1]]
    if len(parts)>2 and re.fullmatch(code_pattern,parts[0]):result.append(parts)
  return result

def digest(relative):return hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()

def generate():
  req=rows('requirements.csv'); nfr=rows('nfr.csv'); dec=rows('decisions.csv');risk=rows('risks.csv');blk=rows('blockers.csv');tc=rows('test-cases.csv');trace=rows('traceability.csv');gates=rows('gates.csv')
  k=parse_md_table('docs/governance/foundational-invariants.md',r'K-\d{2}')
  g=parse_md_table('docs/governance/gates.md',r'G[0-9]')
  status={x['id']:x['status'] for x in gates}
  return {
    'kind':'PREVIEW_ONLY', 'source':'KampusPTS/docs (canonical P00 working files)',
    'counts':{'requirements':len(req),'nfr':len(nfr),'decisions':len(dec),'risks':len(risk),'blockers':len(blk),'tests':len(tc),'traceability':len(trace),'gates':len(gates)},
    'invariants':[{'id':x[0],'title':x[1],'proof':x[2]} for x in k],
    'gates':[{'id':x[0],'phases':x[1],'evidence':x[2],'authority':x[3],'status':status[x[0]]} for x in g],
    'blockers':blk,
    'requirements':req[:8], 'decisions':dec[:5],
    'testCaseStatus':sorted(set(x['status'] for x in tc)),
    'features':json.loads((ROOT/'config/features.example.json').read_text(encoding='utf8'))['features'],
    'hashes':{p:digest(p) for p in ['docs/registries/requirements.csv','docs/registries/decisions.csv','docs/registries/blockers.csv','docs/registries/gates.csv','docs/governance/foundational-invariants.md','docs/governance/gates.md']}
  }

if __name__=='__main__':
  dst=WEB/'src/data/p00-canonical.json';dst.parent.mkdir(parents=True,exist_ok=True)
  dst.write_text(json.dumps(generate(),ensure_ascii=False,indent=2)+'\n',encoding='utf8')
  print('Generated:',dst,'K=',len(generate()['invariants']),'G=',len(generate()['gates']))
