# Google AI Studio — P00 v1.2 Kanonik Aktarım

**Bu ZIP eski proje çıktısının yerine kullanılacak, kanonik referansları içinde taşıyan eksiksiz kaynak paketidir.**

- `P00_REFERENCE/`: SHA-256 doğrulanmış 56 orijinal belge/kayıt.
- `KampusPTS/`: 49 P00 çalışma dosyası orijinal baytlarla aynı; ayrıca bağımsız testler, rapor ve önizleme veri üreteci.
- `file-sha256.json`: bağımsız orijinal hash listesi.
- `src/App.tsx`: salt-okunur React P00 önizlemesi, kaynak verileri `src/data/p00-canonical.json` üzerinden gösterir.
- `KampusPTS/docs/reviews/SUPERSEDED_P00-v1.1_AI_Studio.md`: önceki yanlış başarı raporunun belirgin işaretli arşivi.

**AI Studio çalışma yöntemi:** ZIP'i tüm dosyalarıyla proje kaynağı olarak içe aktar; ZIP içe aktarılamıyorsa Git deposuna açıp kaynak olarak bağla. Sadece `.md` metni yükleyerek kaynak dosyaları koruduğunu iddia etme. `P00_REFERENCE`, `KampusPTS`, `src`, `file-sha256.json` tek çalışma ağacında kalmalı.

```bash
cd KampusPTS
python3 tools/audit_source_integrity.py
python3 tools/validate_p00.py
python3 -m unittest discover -s tests -v
python3 tools/generate_p00_preview.py
python3 tools/build_manifest.py
sha256sum -c manifest.sha256
cd ..
npm install
npm run lint
npm run build
```

`npm install` veya .NET SDK testleri çalıştırılmadıysa `NOT_RUN` yaz. `G0=NOT_APPROVED` değişmez. Canlı mali ve fiziksel komutları açma. P01 geliştirmesine geçme.
