# P00 Temiz Kanonik Taban — Sonraki Fazlara Geçiş

1. Bu klasörün tam içeriği (P00_REFERENCE/ dahil) kaynak depo köküne yüklenir.
2. Aktif eski `KampusPTS/` ve eski `src/data/p00-canonical.json` ile birleştirilmez; önce yedeklenir ve bu paketle değiştirilir.
3. `cd KampusPTS && python3 tools/audit_source_integrity.py`: `REFERENCE=56/56 WORKSPACE=49/49` olmadan önceki başarı iddiası yapılmaz.
4. `python3 tools/validate_p00.py` ve `python3 -m unittest discover -s tests -v` çalıştırılır.
5. Arayüz dosyası `src/data/p00-canonical.json` kanonik araçtan türetilir.
6. G0=NOT_APPROVED ve P01 keşif DATA_NOT_COLLECTED kalır.
7. Sonraki geliştirme yalnız P01'i ekler; özgün P00 dosyalarına müdahale etmez.
