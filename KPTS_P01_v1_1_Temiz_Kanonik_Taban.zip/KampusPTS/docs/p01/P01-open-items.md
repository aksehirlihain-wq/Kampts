# P01 — Devir ve Açık Konular

- `G0=NOT_APPROVED`, `G1=NOT_STARTED`. Bunlar tasarım/kod geliştirmeye engel değildir, canlı kullanımı engeller.
- `DEC-001`, `DEC-002`, `DEC-027` ve P00'da kayıtlı bütün açık kararlar `DECISION_REQUIRED` olarak korunur.
- P00'da kayıtlı 8 BLK sahadaki gerçek kanıt ve yetkili karar olmadan kapatılamaz.
- Gerçek ekip, kampüs, kapı, kamera firmware, entegrasyon kanalı, ödeme/ERP ve mali işleyiş keşfi yapılmamıştır.
- P02, ancak gerçek P01 kaynak uygunluğu ve gerekli POC emniyet sınırları ayrıca denetlendiğinde kontrollü başlanır.
