# SENTETİK GÖSTERİM — saha kaydı değildir
Aşağıdaki anlatım sadece bir iş kuralının nasıl sorgulanacağını gösterir: `34TEST001` plaka metni 3 saniyede 5 kez gözlenmiştir; geçiş sensörü verisi yoktur. Sonuç: **0 teyitli geçiş**, **oturum/ücret yok**; inceleme kuyruğu. Gerçek üretici olayı değildir ve `EVD` değildir.

Örnek mali yönlendirme: `service-X` için `incomeOwner=A`, `collector=B`, `merchant=C` gibi üç ayrı kimlik taşınabilir; bu kodlar kurumsal karar değildir, ödeme bölüşümü/yetkisi üretmez. `issuer` ve `ERP` de ayrıca belirlenir.
