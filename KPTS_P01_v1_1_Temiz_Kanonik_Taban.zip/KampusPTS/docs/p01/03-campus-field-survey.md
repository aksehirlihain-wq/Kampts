# P01.3 — Kampüs / Cihaz / Geçiş Saha Keşif Protokolü
**Durum:** `FIELD_NOT_VISITED` — gerçek değerler boş CSV formlarda tutulacak.

## Sıralama
1. Üniversite → kampüs → tesis/otopark → kapı → şerit → cihaz/sensör hiyerarşisi; fiziksel krokiler.
2. Cihaz marka/model/firmware/sürüm/ürün lisansı; seri/MAC gibi tekil tanımlayıcıların yayınlanmaması; sahada güvenli ayrı kayıt.
3. Kameranın PTS olayı (okuma), kontrolör ACK (komut yanıtı), loop/fotosel/kapı sensörü (gerçek geçiş) ayrı işaretlenir.
4. Hangi sistemin personel kapı yetkisi verdiği; ASManager veya başka sahibi açıkça belirtilir; yetkisiz değiştirme yok.
5. ASManager sürümü, kamera yazılımı, mevcut LPR tolerans/eşleşme yöntemi; veri gönderim mekanizması ve log kaynakları.
6. Ağ VLAN, firewall, NTP, TLS, erişim listeleri, uplink, UPS, offline davranış, kesintide tekrar gönderme ve günlük veri hacmi.
7. Yangın, acil tahliye, anti-sıkışma, bariyer kapanma ve manuel müdahale prosedürü İSG ile teyit.
8. Fiili ölçülen kapasite/giriş-çıkış sayısı bilinmiyorsa `UNKNOWN`; raporda tahmini değer gerçek gibi gösterilmez.

## Kayıtlar
`data/campuses.csv`, `facilities.csv`, `lanes.csv`, `devices.csv`, `network-links.csv`, `physical-evidence.csv`, `operating-metrics.csv`.

## Emniyet kontrolü
- Saha keşfi için bile canlı kontrolör konfigürasyonu değiştirilmez; üretici onayı ve yetki olmadıkça test paketi gönderilmez.
- Üretim sahasında packet capture, görüntü alma veya kişisel veri işleme yetki sahibi onayını ve kayıt planını gerektirir.
- P01 ölçüm ve gözlem fazıdır; `REQ-014..020` P02 üretici POC kanıtı olarak ayrıca yürütülecek.

## Teslim kıstasları
Her pilot aday şeritte çizim, sorumlu kişi, cihaz listesi, güvenilir geçiş teyit kaynağı veya açık `BLK-004`, fiziksel bariyer sahibi veya `BLK-003`, güncel bağlantı haritası ve İSG incelemesi bulunmalıdır.
