# P01.8 — İş Senaryosu / İstisna Kataloğu

**Not:** 32 senaryo ailesi, P03 için keşif girdisidir. **60+ Gherkin/BDD senaryosu ve E2E testi değildir**; P03 ayrıca hazırlayacaktır.

| UC | Senaryo | Persona | Kontrol ilkesi | Sahip | İlişkili REQ |
| --- | --- | --- | --- | --- | --- |
| UC-001 | Ziyaretçi aracı giriş | ziyaretçi | Gözlem+kanıt ile oturum açma | Güvenlik/İşletme | REQ-008;REQ-021 |
| UC-002 | Ziyaretçi aracı çıkış | ziyaretçi | Tarife + doğrulanmış ödeme + güvenli çıkış | İşletme | REQ-008;REQ-022 |
| UC-003 | Personel aracı giriş | personel | ASManager fiziksel erişimi korumak | Güvenlik | REQ-008;REQ-023 |
| UC-004 | Öğrenci araç geçişi | öğrenci | Üye hakları ve geçiş ayrımı | Öğrenci İşleri | REQ-008;REQ-023 |
| UC-005 | Tedarikçi süreli giriş | tedarikçi | Ön izin ve zaman kısıtı | Güvenlik | REQ-008;REQ-021 |
| UC-006 | Misafir konvoy giriş | ziyaretçi | Çoklu araç oturum ayrımı | Güvenlik | REQ-008;REQ-021 |
| UC-007 | Engelli ve tanımlı muafiyet | hak sahibi | Onaylı ve süreli muafiyet | İşletme+Hukuk | REQ-008;REQ-024 |
| UC-008 | Acil araç geçişi | acil | Can güvenliği bağımsız | İSG | REQ-008;REQ-018 |
| UC-009 | Yaya/turnike geçişi | personel/öğrenci | Fiziksel otorite sınırı ve ücret yasağı | Güvenlik+Hukuk | REQ-010;REQ-018 |
| UC-010 | Plaka okunmadı | ziyaretçi | Güvenli manuel inceleme | Güvenlik | REQ-007;REQ-021 |
| UC-011 | Plaka hatalı OCR | ziyaretçi | Bulanık öneri, otomatik karar yok | Güvenlik | REQ-007;REQ-024 |
| UC-012 | Tekrarlı gözlem | tüm araçlar | Çoklu LPR→tek olay ayrımı | BİDB | REQ-007;REQ-017 |
| UC-013 | Geçiş sensörü kayıp | tüm araçlar | UNVERIFIED durumda otomasyon kapalı | Güvenlik | REQ-007;REQ-017 |
| UC-014 | Şerit yönü hatalı | tüm araçlar | Yanlış giriş/çıkışa direnç | Güvenlik | REQ-007;REQ-021 |
| UC-015 | Ters yön ve kuyruk | tüm araçlar | Şerit kontrolü ve istisna | Güvenlik | REQ-007;REQ-021 |
| UC-016 | Ağ kesintisi | tüm araçlar | Durable olay; can güvenliği bağımsız | BİDB | REQ-013;REQ-019 |
| UC-017 | Bariyer ACK var araç geçmedi | tüm araçlar | ACK ≠ geçiş | Güvenlik | REQ-007;REQ-018 |
| UC-018 | Tüzel kişi A tahsilatı | ziyaretçi | Issuer/Merchant/ERP uyumlu | Mali İşler | REQ-011;REQ-012 |
| UC-019 | Tüzel kişi B tahsilatı | ziyaretçi | Hizmet bazlı farklı routing | Mali İşler | REQ-011;REQ-012 |
| UC-020 | Yanlış issuer reddi | ziyaretçi | Belge üretim blokajı | Mali İşler | REQ-012;REQ-026 |
| UC-021 | Ödeme callback iki kez | ziyaretçi | Mükerrer tahsilat yok | Mali İşler | REQ-012;REQ-025 |
| UC-022 | Banka settlement geç | ziyaretçi | CAPTURED ≠ SETTLED | Muhasebe | REQ-012;REQ-025 |
| UC-023 | İade ve iptal | ziyaretçi | Düzeltme fişi/SoD | Mali İşler | REQ-012;REQ-037 |
| UC-024 | Tarife sürüm değişikliği | ziyaretçi | Eski oturuma retroaktif müdahale yok | Mali İşler | REQ-009;REQ-022 |
| UC-025 | Zaman dilimi ve tarife | ziyaretçi | UTC/TR saat uyumu | BİDB+Mali İşler | REQ-009;REQ-022 |
| UC-026 | Abonelik ödeme ardından aktivasyon | abone | Finans ACTIVE ≠ fiziksel VERIFIED_ACTIVE | Güvenlik+Mali İşler | REQ-008;REQ-023 |
| UC-027 | Kamuya açık borç sorgulama | ziyaretçi | Güvenli kimlik doğrulama zorunlu | KVKK | REQ-008;REQ-030 |
| UC-028 | Rapor kanıt kalitesi | yönetici | Gözlem ≠ teyitli geçiş ≠ tahsilat | İç denetim | REQ-013;REQ-029 |
| UC-029 | Kampüsler arası geçiş | personel/abone | Kapsam sınırı | BİDB | REQ-006;REQ-028 |
| UC-030 | Farklı ülke/yabancı plaka | ziyaretçi | Düzensiz plaka ve manuel istisna | Güvenlik | REQ-008;REQ-021 |
| UC-031 | Tahliye sırasında bariyer | tüm kişiler | Bağımsız fiziksel emniyet | İSG | REQ-007;REQ-018 |
| UC-032 | Gelir modeli tarih değişikliği | kurum | Eski tahakkuk routing korunur | Mali İşler | REQ-011;REQ-039 |

## Örnek keşif sorgusu (test PASS iddiası değil)
**Verilen** aynı plaka 5 kez okunmuş; **ve** geçiş kanıtı yok, **beklenen iş kuralı** otomatik oturum/tahakkuk oluşturmamak, olayları inceleme için saklamak. Üretici uyumu P02 ile, kabul testi P03/P04 ile belgelenecek.
