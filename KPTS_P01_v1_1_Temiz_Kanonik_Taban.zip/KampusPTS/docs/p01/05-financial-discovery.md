# P01.5 — Çoklu Tahsilat ve Mali Belge Keşfi

**Güncel durum:** `DEC-001` ve bağlı mali DEC kayıtları açık. Bu belge yasal mali sonuç veya vergi oranı içermez; `P04` kararına veri toplar.

## Dört mali işletme modeli
| Model | İşletme modeli | Gelir sahibi | Merchant / tahsilat | Belge düzenleyici | Muhasebe | Açık karar |
| --- | --- | --- | --- | --- | --- | --- |
| A | Üniversite doğrudan | Üniversite veya hukuken yetkili birim | Kurumun yetkili bankası/PSP hesabı | Belge yükümlüsü onayı | Kurum ERP | Kurum yetki ve muhasebe onayı |
| B | Döner sermaye | Yetkili döner sermaye tüzel birimi | Sözleşmedeki merchant/banka | Uygun belge düzenleyici | İlgili hesap ve ERP | Faaliyet, gelir ve vergi statüsü doğrulaması |
| C | Özel işletmeci | İlgili sözleşmeye bağlı işletmeci | Sözleşmeli PSP/merchant | Sözleşme ve mevzuat gereği issuer | İşletmeci ERP veya kurumsal raporlama | Kira/hasılat payı sözleşme incelemesi |
| D | Çoklu model | Hizmet/zaman/kampüs bazlı belirlenir | İşlem bazlı sözleşme ve merchant | Hizmetin belge düzenleyicisi | İlgili tüzel kişi ERP | Fon bölüşümü varsayılmaz; ayrı izinli akış |

## İşlem bazlı ayrı roller
- `ServiceOwner`: Hizmeti işleten birim; geliri otomatik olarak sahiplenmez.
- `IncomeOwnerLegalEntity`: Tahakkukun hukuken alacaklısı.
- `CollectionAgent`: Tahsilata hukuken veya sözleşmeyle yetkili taraf.
- `MerchantAccount`: PSP/banka kabul sözleşmesine bağlı hesap.
- `InvoiceIssuer`: Hukuken mali belgeyi düzenleyen taraf.
- `ErpLedgerOwner`: Nihai muhasebe kaydının sahibi.
- `DataController`: KVKK veri sorumlusu; mali rollerle otomatik aynı değildir.

Yönlendirme, en az `(campusId, serviceId, validFrom, validTo, legalEntity, merchant, issuer, currency, approvedPolicyVersion)` ile ilişkilendirilir. Tarihi işlem sonradan yeni routing kuralına sessizce taşınmaz; belirsiz durumda belge/tahsilat bloklanır.

## Mali keşif ajandası
| Kimlik | Konu | İlgili kararlar | Karar sahibi |
| --- | --- | --- | --- |
| FIN-01 | Ücret tahakkukunun hukuki dayanağı | DEC-001;DEC-027 | Mali İşler+Hukuk |
| FIN-02 | Gelir sahibi + tahsilat yetkilisi | DEC-001;DEC-026 | Mali İşler+Hukuk |
| FIN-03 | Merchant ve banka hesabı eşlemesi | DEC-031;DEC-003 | Mali İşler+Banka |
| FIN-04 | e-Fatura/e-Arşiv issuer ve belge zamanı | DEC-002;DEC-028;DEC-030 | Mali İşler+Vergi |
| FIN-05 | Farklı kampüs farklı issuer | DEC-024;DEC-028 | Mali İşler+Hukuk |
| FIN-06 | KDV ve diğer vergi sınıflaması | DEC-014 | Mali İşler+Vergi |
| FIN-07 | İade / iptal / chargeback | DEC-012;DEC-023 | Mali İşler+Banka |
| FIN-08 | ERP hesap planı, masraf merkezi | DEC-005 | Muhasebe+ERP |
| FIN-09 | Banka settlement/valör, komisyon | DEC-022;DEC-031 | Muhasebe+Banka |
| FIN-10 | Fon bölüştürme ve lisans/sözleşme | DEC-026 | Hukuk+Mali İşler+Banka |
| FIN-11 | Avans/cüzdan ertelenmiş gelir | DEC-013 | Mali İşler+Vergi |
| FIN-12 | Kasa/nakit/ÖKC değerlendirmesi | DEC-003;DEC-030 | Mali İşler+Vergi |

## Akışın kontrol noktaları
`PlateObservation` → `PassageEvidence` → `ParkingSession` → `Quote` → `Charge` → `PaymentIntent` → `PaymentTransaction` → `ProviderSettlement` (ayrı) → `Invoice` → `LedgerEntry` → `ERP` → `Reconciliation`. Her ok operasyonel ve hukuki koşullara bağlıdır; belge zamanı sabit varsayılmaz.

**Muhasebe değişmezi:** POSTED alt defter değişmez; iade yeni ters kayıt üretir. `PaymentTransaction` ≠ `ProviderSettlement`; `PaymentIntent` ≠ muhasebe fişi.

## P04 aşamasına devredilecek kanıt
Hizmet bazlı sözleşme/gelir dayanağı, vergi görüşü, GİB statüsü ve test protokolü, PSP sözleşmesi, merchant ve banka hesap yetkileri (maskeli), ERP hesap eşlemesi, komisyon ve valör şeması, yetkili onay. Kaynak yoksa `DECISION_REQUIRED` ve `BLK` korunur.
