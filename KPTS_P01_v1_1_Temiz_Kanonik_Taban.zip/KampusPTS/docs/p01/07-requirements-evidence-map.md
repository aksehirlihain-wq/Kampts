# P01.7 — Gereksinim / Bilgi / Kanıt Eşleme

P00 `REQ-005..REQ-013` kimlikleri değiştirilmemiştir. P01 için yeni REQ kimliği oluşturulmadı.

| REQ | Zorunlu keşif çıktısı | İlgili kaynak | Sahip | Kanıt hedefi | Kabul kontrolü |
| --- | --- | --- | --- | --- | --- |
| REQ-005 | Stakeholder roster + görüşme tutanakları | S01..T03 | Sponsor+BİDB | P01-A01..A14 | P01-TC-01 |
| REQ-006 | Kampüs/tesis/şerit + hizmet katalogu | campuses/facilities/lanes/paid-services | İşletme+Güvenlik | P01-EV-01 | P01-TC-02 |
| REQ-007 | Cihaz/firmware/ağ/PGT kaydı | devices/network-links/physical-evidence | BİDB+Güvenlik | P01-EV-02 | P01-TC-03 |
| REQ-008 | Persona bazında mevcut süreç haritası | UC-001..UC-032 | İşletme+Güvenlik | P01-EV-03 | P01-TC-04 |
| REQ-009 | Tarife, muafiyet ve abonelik envanteri | interviews I01..I04 | Mali İşler+İşletme | P01-EV-04 | P01-TC-05 |
| REQ-010 | Otopark dışı ücret hukuki kaynakları | DEC-027, BLK-002 | Hukuk | P01-EV-05 | P01-TC-06 |
| REQ-011 | Tüzel kişilik/sözleşme/hizmet matrisi | legal-entities/financial-flows | Hukuk+Mali İşler | P01-EV-06 | P01-TC-07 |
| REQ-012 | Tahakkuk/PSP/issuer/ERP şemaları | financial-flows/current-integrations | Mali İşler+ERP | P01-EV-07 | P01-TC-08 |
| REQ-013 | Kapasite/performans/DR hedef kartı | operating-metrics/NFR worksheet | BİDB | P01-EV-08 | P01-TC-09 |

Her REQ ancak EVD mevcut ve rol sahibi onayladıysa `VERIFIED`. Buradaki EVD adları **hedef kimlik**, mevcut delil değildir. P01 bu aşamada `DATA_NOT_COLLECTED` durumundadır.
