# P01.2 — Paydaş Görüşmeleri ve Keşif Soruları

**Şimdiki durum:** Görüşmeler `NOT_HELD`. Kişi bilgileri toplanmadı; rol sahipleri atanmadı. Sorular karar üretmez; kanıt sağlar.

## Paydaş / beklenen çıktı matrisi
| Paydaş | Ana sorumluluk | Keşif odağı | İstenen kanıt | Kod |
| --- | --- | --- | --- | --- |
| Sponsor/Rektörlük | Yatırım ve GO/NO-GO | Fon tahsisi, kurum yetkisi, paydaş ataması | Sponsorluk/charter imzası | P01-A01 |
| BİDB | Mimari, ağ, IAM, altyapı | Güvenlik zonları, sunucu, NTP, veri akışı | Onaylı topoloji ve sistem listesi | P01-A02 |
| Güvenlik/Nizamiye | Şerit, kamera, bariyer, olay | Geçiş otoritesi, acil hâl ve manuel işlem | Kapı prosedürü ve saha gözlemi | P01-A03 |
| İdari Mali İşler/İşletme | Ücret tarifesi, park operasyonu | Hizmet kataloğu, indirim ve muafiyet kuralları | İmzalı iş akışı | P01-A04 |
| Strateji/Mali İşler | Gelir, belge, kapanış | Tahsilat ve belge yetkileri, mutabakat | Kurum kararı/şema | P01-A05 |
| Döner Sermaye | Olası işletmeci/gelir sahibi | Tüzel kimlik, cari, banka hesabı ayrımı | Yetki ve sözleşme | P01-A06 |
| Hukuk/KVKK | İşleme hukuku ve sözleşmeler | Ücret alma dayanağı, saklama, veri sorumlusu | Hukuk görüşü | P01-A07 |
| İSG/Acil durum | Emniyet ve tahliye | Bariyer bağımsız emniyet, prosedür | İSG kontrol tutanağı | P01-A08 |
| İK/Öğrenci İşleri | Üyelik referansı | Görevden ayrılma, mezuniyet, doğrulama | Veri sözleşmesi | P01-A09 |
| ERP/Muhasebe sahibi | Yevmiye ve hesap planı | Defter/ERP sınırı, dönem kapanışı | Şema/işlem örneği | P01-A10 |
| Banka/PSP temsilcisi | Merchant ve tahsilat | Ürün yetkisi, iade, settlement, valör | Resmî sözleşme/API | P01-A11 |
| e-Belge entegratörü | Issuer ve belge gönderim | GİB izin kapsamı, sandbox, hata/iptal | Sözleşme + test protokolü | P01-A12 |
| GeoVision/diğer PTS üreticisi | Donanım/olay sözleşmesi | Webhook/POST, log, sürüm, olay kalitesi | Resmî kılavuz ve POC | P01-A13 |
| İç denetim | Kontrol ve SoD | İade, manuel değişiklik, audit, mali farklar | Denetim kriterleri | P01-A14 |

## Standart sorular
| Kod | Paydaş | Soru | Beklenen kanıt |
| --- | --- | --- | --- |
| S01 | Sponsor | İlk pilot kapsamı hangi kampüs, hangi otopark ve hangi hizmetlerle sınırlandırılacak? | Kapsam kararı |
| S02 | Sponsor | Ücretlendirme için kurum içi onay zinciri ve imza yetkileri kimde? | Yetki belgesi |
| S03 | Sponsor | Başarı ölçütü; gelir doğruluğu, geçiş sayısı, kesinti toleransı ve operatör iş yükü ne olacak? | KPI taslağı |
| B01 | BİDB | Mevcut ASManager sunucu, sürüm, lisans, yedek ve ağ bölümleri nelerdir? | Sistem envanteri |
| B02 | BİDB | Kamera ve kontrolörlerin fiziksel ağ erişimi, VLAN, firewall ve VPN düzeni nedir? | Ağ şeması |
| B03 | BİDB | NTP, log merkezi, SIEM, yedekleme, restore, sertifika/sır yönetimi nasıl çalışıyor? | Politika/topoloji |
| B04 | BİDB | Hedef kapasite: günlük okuma, giriş/çıkış sayısı, eşzamanlı şerit, tutma süresi? | Kapasite metrikleri |
| G01 | Güvenlik | Her şeritte ANPR, sensör, loop, fotosel, kart okuyucu, bariyer bağlantısı nasıl? | Şerit krokisi |
| G02 | Güvenlik | Bariyeri şu anda hangi ürün/kontrolör ve hangi şartlarda açıyor? | Yetki matrisi |
| G03 | Güvenlik | Plaka okuma ile gerçek geçiş teyidini ayıran güvenilir olay kaynağı var mı? | Geçiş kanıtı |
| G04 | Güvenlik | Ters geçiş, çifte okuma, kuyruk, tailgating ve sahte plaka koşulları nasıl yönetiliyor? | Olay örnekleri |
| G05 | Güvenlik | Elektrik/ağ arızasında ve tahliyede güvenli manuel prosedür nedir? | Acil prosedür |
| I01 | İşletme | Giriş/çıkışta ücretsiz süre, günlük limit, kademeli tarife ve abonelik kuralı nedir? | Tarife kararı |
| I02 | İşletme | Personel/öğrenci/ziyaretçi/tedarikçi/yabancı/engelli/kurum aracı ayrımı nasıl? | Hizmet-persona matrisi |
| I03 | İşletme | Muafiyet ve manuel geçiş kimin onayı ve gerekçesiyle yapılır? | Yetki ve istisna tablosu |
| I04 | İşletme | Geciken çıkış, yanlış plaka, oturum çakışması ve kayıp kayıtta operatör akışı nedir? | İstisna tutanağı |
| M01 | Mali İşler | Her ücretli hizmette alacak hakkının sahibi hangi tüzel kişilik? | DEC-001 kanıtı |
| M02 | Mali İşler | Merchant/banka hesabı/faturayı düzenleyen ve ERP kaydı aynı mı farklı mı? | Mali routing matrisi |
| M03 | Mali İşler | Ödeme türleri, provizyon/tahsilat/settlement ayrımı, komisyon ve valör nasıl? | Banka/PSP süreçleri |
| M04 | Mali İşler | e-Fatura/e-Arşiv, KDV, belge zamanı, iade/iptal ve ÖKC yükümlülükleri neler? | Hukuk+vergi onayı |
| M05 | Mali İşler | ERP hesap planı, maliyet merkezi, dönem kapanışı ve mutabakat toleransı nasıl? | ERP örnek fiş |
| H01 | Hukuk/KVKK | Otopark dışındaki hangi geçiş hizmetlerinde ücret alma yetkisi var? | DEC-027 görüşü |
| H02 | Hukuk/KVKK | Veri sorumlusu/veri işleyen rolleri her işletme için kimlerde? | Veri sözleşmesi |
| H03 | Hukuk/KVKK | Plaka/foto/borç/kimlik verileri için amaç, dayanak, süre ve saklama nerede? | Envanter |
| H04 | Hukuk/KVKK | Borç görüntüleme ve kamuya açık sorgulamada güvenli kimlik doğrulama yolu nedir? | Gizlilik kararı |
| E01 | İSG | Bariyer ve turnike acil durumda yazılımdan bağımsız açılabiliyor mu? | Yerinde kontrol |
| E02 | İSG | Anti-sıkışma, fotosel, acil buton, yangın alarmı ve geçiş serbest bırakma düzeni nedir? | İSG tutanağı |
| T01 | Tedarikçi | Resmî API sürümü, event payload ve cihaz firmware belgesi var mı? | Üretici kılavuzu |
| T02 | Tedarikçi | Olay zamanı, imza/kimlik doğrulama, tekrar gönderme, dedup ve cache özellikleri? | POC tasarımı |
| T03 | Tedarikçi | LPR okunma anı, gate acknowledgement ve fiziksel passage farklı olaylar mı? | Eşleştirme örneği |
| F01 | İK/Öğrenci İşleri | Yetkili kişi/grup senkronizasyonunda kaynak sahip ve değişiklik SLA kimde? | Kaynak sözleşmesi |
| F02 | İK/Öğrenci İşleri | İlişik kesme ve mezuniyet erişim geri alma kaç adımda yapılıyor? | Yaşam döngüsü |

## Görüşme protokolü
- Kayıt adı `P01-MIN-{date}-{group}.md`; katılımcı isimleri bu dağıtılabilir pakette `TO_ASSIGN` olarak kalır.
- Her cevap: `CONFIRMED` yalnız imzalı kaynakla; `UNKNOWN` cevap yok; `ASSUMED` geçici taslak ve süresi olan kayıt; `DECISION_REQUIRED` kurum yetkisi gerektirir.
- Gerçek ekran görüntüleri/veri paketleri ancak maskelenmiş, açık izinli, veri işleme envanterine göre saklanan özel EVD deposuna alınabilir.
