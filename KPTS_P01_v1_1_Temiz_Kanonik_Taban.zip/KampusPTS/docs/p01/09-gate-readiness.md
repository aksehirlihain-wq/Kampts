# P01.9 — P01 Keşif Çıkışı / G1 Yeterlilik Kontrolü

**Önemli:** `G1` P01–P04 toplu kapısıdır; P01 tek başına G1'i açamaz.

| Kontrol | Şimdiki durum | Kanıt |
|---|---|---|
| P00/G0 imza ve yetkili sponsor | BLOCKED | `BLK-008`, imza yok |
| Pilot kampüs/saha ve rol atamaları | NOT_VERIFIED | Kampüs/rol CSV boş |
| Kullanıcı/aktör görüşmeleri | NOT_RUN | 32 sorunun tümü NOT_COLLECTED |
| Kampüs/şerit/cihaz envanteri | NOT_RUN | Envanter CSV boş |
| ASManager kanıtlı entegrasyon kanalı | P02_REQUIRED | `BLK-007` |
| Fiziksel passage/ACK ve bariyer otoritesi | P02_REQUIRED | `BLK-003`, `BLK-004` |
| Ücretli hizmet yetkisi ve gelir sahibi | P04_REQUIRED | `BLK-001`, `BLK-002` |
| Belge/PSP/merchant/ERP kararları | P04_REQUIRED | `BLK-005`, `BLK-006` |
| KVKK/İSG prosedür ve karar sahipleri | NOT_VERIFIED | Kurum saha kanıtı yok |
| SRS 60+ GWT ve test izlenebilirliği | P03_REQUIRED | UC kataloğu sadece tohum |
| G1 çoklu paydaş onayları | NOT_APPROVED | İmzalar yok |

## P01'i gerçek keşif olarak kapatma ölçütü
- Saha dosyaları gerçek yetkili kişi tarafından doldurulmuş, hangi kaynak belgesinin teyit ettiği yazılmış, maskeleme uygulanmış.
- REQ-005..013 için `EVD` ve onay referansı var; her bilinmeyen `DEC/BLK` sahibi atanmış.
- Gerçek kanıt gösterilemeyen alanlar çözülmüş sayılmaz, P02/P04'e açık ve risk sınıflamasıyla aktarılır.
- Başlangıç/bitiriş kararını BİDB+İşletme+Güvenlik+Mali İşler imzalar; P00/G0 resmen onaylı değilse P01 kurumsal statüsü `DRAFT` kalır.

## Bir sonraki aşama
`P02 — GeoVision ve marka bağımsız cihaz uyumluluk keşfi/POC`. Önce G0 ve envanter erişimi. Test ayrı change window/saha yetkisi gerektirir.

**GO/NO-GO taslak alanı:** P01 `NO-GO / INSUFFICIENT_FIELD_EVIDENCE` (tasarım tamam; saha veri eksik).  
Karar sahibi: __________  Tarih: __________  İmza: __________  Kanıt no: __________
