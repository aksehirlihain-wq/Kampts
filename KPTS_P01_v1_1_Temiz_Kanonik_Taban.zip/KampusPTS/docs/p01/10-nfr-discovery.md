# P01.10 — Sayısal Olmayan NFR Toplama Kartı

**Kural:** Gerçek ölçüm yokken keyfi 99.9 SLA, 200ms veya 5 dakika RTO hedefi verilmez. Kurum bağlayıcı hedefleri `DEC-019` sonrasında tanımlar.

| NFR | Alan | Toplanacak veri | Karar sahibi | Mevcut değer | Çıkış |
| --- | --- | --- | --- | --- | --- |
| NFR-001 | IAM/SSO | Kurum IdP listesi, MFA politikası, uzaktan operatör | BİDB | UNKNOWN | G1 hedef tanımı |
| NFR-002 | İzolasyon | Tenant, LegalEntity, Campus ve şerit kapsamı | BİDB/Hukuk | UNKNOWN | Yetki matrisi |
| NFR-003 | Şifreleme | TLS, HSM/KMS, yedek, sır yönetimi | BİDB | UNKNOWN | Kurumsal kontrol |
| NFR-004 | Kart verisi | PSP hosted ödeme biçimi; token | Mali İşler | UNKNOWN | PSP seçimi |
| NFR-005 | Audit | Kim, ne, ne zaman, neden, log integrite | İç denetim | UNKNOWN | Audit kriteri |
| NFR-006 | Kapasite | Peak kamera olay/saniye, giriş/çıkış/saat | İşletme | UNKNOWN | Ölçüm planı |
| NFR-007 | Kullanılabilirlik | Haftalık çalışma saati, izinli bakım | Sponsor+BİDB | UNKNOWN | SLA kararı |
| NFR-008 | DR/RPO | Son kabul edilen veri kaybı üst sınırı | BİDB | UNKNOWN | RPO kararı |
| NFR-009 | DR/RTO | Servis kurtarma üst sınırı | BİDB | UNKNOWN | RTO kararı |
| NFR-010 | Gecikme | Okuma→gözlem→quote; kaynak p95/p99 | BİDB | UNKNOWN | Hedef metrik |
| NFR-011 | Çevrimdışı | Saha gateway dayanma/kayıt ve can güvenliği | Güvenlik+BİDB | UNKNOWN | Ağ simülasyonu |
| NFR-012 | KVKK | Veri minimizasyonu, retansiyon, imha | Hukuk | UNKNOWN | İmha politikası |
| NFR-013 | İzlenebilirlik | Correlation ID, log, tracing, alarm | BİDB | UNKNOWN | SRE observability |
| NFR-014 | İzleme | Alarm eşikleri, SLA ihlali, bildirim | BİDB | UNKNOWN | On-call planı |
| NFR-015 | Performans | Veritabanı büyüme, indeksleme, rapor | BİDB | UNKNOWN | Hacim ölçümü |
| NFR-016 | Operasyon | Destek, yetki devir, erişilebilir UI | İşletme+BİDB | UNKNOWN | Kullanıcı kabulü |

CSV şablonuna ölçüm, birim, örneklem dönemi, kanıt yöntemi, paydaş onayı girilmelidir.
