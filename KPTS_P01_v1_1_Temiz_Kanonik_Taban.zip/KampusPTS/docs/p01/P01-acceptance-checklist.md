# P01 — Kaynak Kabul Ölçütleri

- [x] 56/56 P00 kaynak + 49/49 çalışma dosyası özgün SHA-256 eşitliği (yerel bağımsız kontrol)
- [x] 17/17 P01 CSV dosyası özgün kolon/içerik eşitliği (yerel kontrol)
- [x] 14 paydaş, 32 soru, 32 senaryo, 16 NFR ve 9 REQ–kanıt eşlemesi özgün şemayla mevcut
- [x] Başlangıç saha listelerinde veri yok; sahte cihaz/banka/kanıt yok
- [x] G0/G1 açılmadı, canlı bayraklar OFF
- [ ] Google AI Studio'ya temiz kaynakların birebir yüklenip yeniden denetlenmesi
- [ ] Gerçek React/TypeScript build sonucu bu ortamda onaylanması
- [ ] Gerçek saha keşfi ve kurum yetkili onayı

P01 kaynak hazırlığı, kurumsal G1 onayına eşdeğer değildir.
