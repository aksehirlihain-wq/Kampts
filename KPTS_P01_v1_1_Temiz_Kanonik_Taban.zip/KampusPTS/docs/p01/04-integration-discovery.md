# P01.4 — Üretici-Bağımsız Entegrasyon Keşfi

## Zorunlu kanal sorguları
**ASManager 6.3.0 (yerinde):** Güncel işletilen binary/build ve lisans; LPR/Webhook yeteneği gerçekten var mı; hangi olay için, hangi sürümde; üretici kılavuzu sayfası; gerçek maskeli payload; kimlik doğrulama, TCP portları, tekrar gönderim, ordering, saat kaynağı, ACK; hiçbir endpoint varsayılmaz.

**GV-LPR2812-DL (yerinde):** Firmware ve HTTP POST/olay yayın yeteneği belgeli mi? ASManager ve kamera bir olayın eşzamanlı iki kaynağı olabilir mi; mükerrerlik analizi; üretici onaylı izole POC yalnız P02'de.

**Başka marka kamera:** ONVIF Profile M desteği *model+firmware üzerinde doğrulanmış mı*? Profile M varlığı tek başına fiziksel geçiş ispatı değildir. Profile M desteklenmiyorsa belgelendirilmiş REST/SDK, RTSP+ayrı OCR ya da offline adaptör alternatifi.

**Ödeme/ERP/e-belge:** Gerçek endpoint, sözleşme, sandbox ve kimlik bilgileri P01'de yalnız envanter; bunları kurumsal onay olmadan etkinleştirmek yasak.

## Nitelik matrisi
Her entegrasyonda: `Producer`, `Transport`, `SchemaVersion`, `Auth`, `Timestamp`, `DeliveryGuarantee`, `DuplicateKey`, `EventId`, `RetryPolicy`, `EvidenceSource`, `DataClassification`, `Retention`, `Owner`, `ContractStatus`. Bilinmeyen alanlar `UNKNOWN`.

## Olay sözleşmesi ayrımı
- `PlateObservation`: plaka, güven ve gözlem zamanı; *asla* geçiş veya mali hak değil.
- `PassageEvidence`: sensör/kontrolör/kanıt kaynağı ile geçişe dair ayrı sinyal; güven düzeyi `CONFIRMED / CORRELATED / UNVERIFIED`.
- `GateAck`: kontrolörün komuta verdiği yanıt; yalnız ACK fiziksel geçiş garantisi değildir.
- Fiziksel `Passage` ve abonelik `PhysicalAccessProvisioning` için ayrı teyit.

## Çift kayıt, belirsizlik ve offline
Bir olayın farklı üreticilerden kopyaları, değişen plaka OCR, kesintiden sonra eski olay, kuyruğun yeniden oynatılması, saat sapması ve kayıp teyit ayrı senaryo. Idempotent inbox/outbox tasarımının ölçümü P02/P03'e devredilir.

## Resmî doğrulama kaynakları
- ONVIF Profile M: https://www.onvif.org/profiles/profile-m/ (plaka meta-verisi ve olay arayüzü; ürün bazlı uygunluk ayrıca doğrulanacak).
- GeoVision ASManager resmî indirme sayfası: https://www.geovision.com.tw/download/product/GV-ASManager%20%28Access%20Control%29 (sürüm bilgisi sahadaki kurulum yerine geçmez).
- GeoVision GV-LPR resmî indirmeleri: https://www.geovision.com.tw/us/download/product/GV-LPR (web sürüm listesinde 19.10.2026 tarihli v6.4.0 görülebilir; mevcut v6.3.0 otomatik yükseltilmez).
