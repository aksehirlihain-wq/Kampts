# P01.1 — Keşif Anayasası ve Sınırlar
**Statü:** `DESIGNED`, gerçek saha incelemesi `NOT_RUN` • **Sahip:** BİDB + İşletme (atanacak)  
**Bağımlılık:** P00/G0 `NOT_APPROVED`; P01 keşif taslağı hazırlanabilir fakat kurum adına yetkili inceleme/üretim müdahalesi sayılamaz.

## Sorular
- Kampüsleri, otoparkları, nizamiyeleri, yaya girişlerini ve tahsilata aday hizmetleri kim işletiyor?
- Hangi tesislerde bariyer, turnike, kart okuyucu, ANPR kamera, sensör ve kesintisiz enerji var?
- Üniversite, döner sermaye, yüklenici ve diğer tüzel kişilikler hangi hizmetlerde sözleşme tarafı?
- Hangi işlemler mevcut ASManager / finans ERP / öğrenci ve personel veri kaynaklarında yönetiliyor?
- Gerçek kameranın plaka gördüğü anda mı, sahadaki kontrolörün geçişi teyit ettiği anda mı oturum açılacak?
- İş kazası, yangın, afet, ağ kesintisi, cihaz arızasında güvenli işletme nasıl sürdürülecek?

## Saha kapsamı
- Çoklu kampüs ve çoklu tüzel kişilik; her tesis için benzersiz yerel `campusId`, `facilityId`, `laneId`.
- Otopark ücretlendirmesi aday hizmet. Diğer ücretlendirilen kampüs/yaya geçişleri `DEC-027` sonuçlanmadan **ücretli hizmet olarak açılmaz**.
- Mevcut GeoVision GV-ASManager 6.3.0 ve GV-LPR2812-DL korunur; P02'de sürüm/firmware ve API kanıtı yapılır.
- Test örnekleri gerçek plaka/TCKN/VKN, fotoğraf ve ticari sır içermez.

## Çalışma ürünü ve kanıtlar
Her görüşme için tarih, yetkili kurum/rol, konu, karar ihtiyacı, doğrulama belgesi, katılımcı doğrulaması ve hassas veri sınıflandırması. Her saha şeridi için kamera → olay kaynağı → controller → sensör → bariyer zincirinin çizimi. Her mali hizmet için fiyat, gelir sahibi, merchant, issuer, vergi, banka ve ERP akışının ayrı satırda gösterimi. Kaynak yoksa `EVIDENCE_PENDING`.

## Kabul
P01 için envanter satırlarının gerçek kimliklerle doldurulması, paydaş mülakat tutanakları, sorumlu ataması, açık BLK/DEC sahipliği, REQ-005..013 işlenmesi gerekir. Bunlar sağlanmadan P01 `DISCOVERED` sayılmaz. P01 tamamlanması **G1 onayı değildir**.
