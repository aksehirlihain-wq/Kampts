# P01.6 — KVKK, Ağ ve Fiziksel Güvenlik Keşfi
**Statü:** `NOT_VERIFIED`. Bu belge bir KVKK uygunluk beyanı değildir.

## Veri sınıfları ve amaç alanları
- Plaka/araç görüntüsü/olay zamanı: kişisel veri ilişkisi, saklama amacı, işleme şartı, fotoğrafı kimin gördüğü ve erişim kayıtları analiz edilir.
- Personel/öğrenci eşlemesi: asgari gerekli alan, değişiklik doğruluğu, de-provisioning süresi; mümkün olan durumda kurum kimliği referansı.
- Borç/tahsilat/belge: ayrı gizlilik sınıfları, mali mevzuat saklama yükümlülüğü, erişim ve denetim.
- API sırları/PSP token'ları: secrets manager; gerçek ödeme kart numarası/PAN/CVV uygulamaya alınmaz.
- Ziyaretçi/nizamiye fotoğraf gösterimi: erişim yetki matrisi, operatör ekranı, otomatik kilit, ekran görüntüsü ve log politikası.

## Saha görüşmelerinde zorunlu kanıt
Veri sorumlusu/veri işleyen sözleşmesi, işleme amaç ve hukuki dayanak, aydınlatma kanalları, alan bazlı retansiyon ve imha, yetkili dış servis/alt yüklenici listesi, kullanıcı rolleri, transfer sınırları. Açık karar: `DEC-011`, `DEC-016`, `DEC-029`.

## Güvenlik ve ayrım
MFA/OIDC, kampüs ve tüzel kişilik ABAC, SoD, ayrı operator/auditor/finance rolleri, immutable işlem geçmişi, gerçek üretici portları için en az yetki, network segmentation, TLS/mTLS uygunluk, kesinti ve NTP senkronizasyonu sorulur. `G1` hedefleri kurum tarafından doldurulmalıdır.

## Yetkisiz borç sorgusu yasağı
Yalnız plaka bilen kişinin borç ve kimlik bilgilerine erişebilmesi güvenli varsayılmaz. KVKK Kurulu'nun otopark işleten veri sorumlusu hakkında 2023/924 sayılı kararı borç sorgulamada çift faktörlü doğrulama ve aydınlatma yönünden özellikle dikkate alınmalıdır.
Kaynak: https://www.kvkk.gov.tr/Icerik/7763/2023-924

## İSG ve fail-safe
Bariyer anti-sıkışma, yangın açma, acil tahliye ve can güvenliği PTS ve tahsilata bağlı olamaz. Fiziksel kontrolün gerçek sahibine müdahale edilmez; test için yazılı emniyet izni gerekir.
