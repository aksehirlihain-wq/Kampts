#!/usr/bin/env python3
"""P01 static discovery-pack validation; not a field integration test."""
from pathlib import Path
import csv,json,sys,hashlib
ROOT=Path(__file__).resolve().parent.parent
DIR=ROOT/'docs'/'p01'
REG=ROOT/'docs'/'registries'

def rd(path):
 with path.open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))

def check():
 assert (DIR/'01-discovery-charter.md').exists()
 reqs=rd(REG/'requirements.csv');dec=rd(REG/'decisions.csv');gates=rd(REG/'gates.csv')
 assert len(reqs)==40 and len(dec)==31,(len(reqs),len(dec))
 assert next(r for r in gates if r['id']=='G0')['status']=='NOT_APPROVED'
 assert next(r for r in gates if r['id']=='G1')['status']=='NOT_STARTED'
 assert len(rd(DIR/'data/interview-questionnaire.csv'))>=30
 assert all(r['answer_status']=='NOT_COLLECTED' and not r['answer'] for r in rd(DIR/'data/interview-questionnaire.csv'))
 assert len(rd(DIR/'data/use-case-catalog.csv'))>=30
 for filename in ['campuses.csv','facilities.csv','lanes.csv','devices.csv','network-links.csv','physical-evidence.csv','paid-services.csv','legal-entities.csv','financial-flows.csv','current-integrations.csv','operating-metrics.csv','open-findings.csv']:
  assert not rd(DIR/'data'/filename),f'unexpected field data in {filename}'
 assert all(r['evidence_status']=='PENDING' for r in rd(DIR/'data/p01-requirement-evidence-plan.csv'))
 assert all(r['status']=='NOT_MEASURED' for r in rd(DIR/'data/nfr-discovery.csv'))
 f=json.loads((ROOT/'config/features.example.json').read_text(encoding='utf-8'))
 # Required P00 active feature flags are all disabled (P00 validation also covers this).
 assert not 'EVD' in [p.stem for p in (ROOT/'evidence/P01').glob('*')]
 print('PASS: P01 design-only structure: 40 REQ, 31 DEC, G0 not approved, G1 not started; no simulated field evidence.')
 print('Questionnaire:',len(rd(DIR/'data/interview-questionnaire.csv')), 'use-case families:',len(rd(DIR/'data/use-case-catalog.csv')))
 return True
if __name__=='__main__':check()
