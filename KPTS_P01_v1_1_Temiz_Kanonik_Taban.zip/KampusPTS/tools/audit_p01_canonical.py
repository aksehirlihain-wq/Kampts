#!/usr/bin/env python3
"""Independent P00/P01 byte identity and static discovery fidelity verifier."""
from pathlib import Path
import sys,json,csv,hashlib
ROOT=Path(__file__).resolve().parents[2]
K=ROOT/'KampusPTS'
SURVEY=['campuses.csv','facilities.csv','lanes.csv','devices.csv','network-links.csv','physical-evidence.csv','operating-metrics.csv','legal-entities.csv','paid-services.csv','financial-flows.csv','current-integrations.csv','open-findings.csv']
REGISTRY=['stakeholder-roster.csv','interview-questionnaire.csv','use-case-catalog.csv','nfr-discovery.csv','p01-requirement-evidence-plan.csv']
NON_P00={'P01-README.md','P76-README.md','docs/gates/G1-P04-submission-checklist.md','docs/gates/G3-P08-readiness.md','docs/p05/01-architecture-blueprint.md','docs/p76/FINAL-HANDOFF.md','docs/p76/OPEN-ACCEPTANCE-ITEMS.md'}

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None

def rows(name):
 with (K/'docs/p01/data'/name).open(newline='',encoding='utf-8-sig') as f:
  r=csv.DictReader(f); return list(r),r.fieldnames

def check():
 errors=[];counts={}
 p00=json.loads((ROOT/'file-sha256.json').read_text('utf8'))['files']
 counts['p00_reference']=sum(sha(ROOT/'P00_REFERENCE'/r['path'])==r['sha256'] for r in p00)
 counts['p00_workspace']=sum(sha(K/r['path'])==r['sha256'] for r in p00 if r['path'] not in NON_P00)
 if len(p00)!=56 or counts['p00_reference']!=56 or counts['p00_workspace']!=49:errors.append('P00 canonical hash mismatch')
 p01=json.loads((ROOT/'p01-reference-sha256.json').read_text('utf8'))['files']
 counts['p01_reference']=sum(sha(ROOT/'P01_REFERENCE'/r['path'])==r['sha256'] for r in p01)
 counts['p01_workspace']=sum(sha(K/r['path'])==r['sha256'] for r in p01)
 counts['p01_expected']=len(p01)
 if counts['p01_reference']!=len(p01) or counts['p01_workspace']!=len(p01):errors.append('P01 original source bytes/schema/content changed')
 for x in SURVEY+REGISTRY:
  a,b=rows(x)
  with (ROOT/'P01_REFERENCE/docs/p01/data'/x).open(newline='',encoding='utf-8-sig') as f: r=csv.DictReader(f); er=list(r);ef=r.fieldnames
  if b!=ef or a!=er:errors.append('P01 CSV reference mismatch: '+x)
 counts['csv_count']=len(SURVEY+REGISTRY)
 if any(rows(x)[0] for x in SURVEY):errors.append('Unexpected unsourced field survey data')
 for n,l in [('stakeholder-roster.csv',14),('interview-questionnaire.csv',32),('use-case-catalog.csv',32),('nfr-discovery.csv',16),('p01-requirement-evidence-plan.csv',9)]:
  if len(rows(n)[0])!=l:errors.append(f'Expected {l} records in {n}')
 with (K/'docs/registries/gates.csv').open(encoding='utf-8-sig',newline='') as gf:
  gates={r['id']:r['status'] for r in csv.DictReader(gf)}
 if gates.get('G0')!='NOT_APPROVED' or gates.get('G1')!='NOT_STARTED':errors.append('Gate status changed')
 features=json.loads((K/'config/features.example.json').read_text('utf8'))['features']
 if not all(v is False for v in features.values()):errors.append('Live feature enabled')
 from generate_p01_preview import generate
 result=generate()
 actual=json.loads((ROOT/'src/data/p01-discovery.json').read_text('utf8'))
 if result!=actual:errors.append('P01 generated JSON differs from source CSV projection')
 manifest=(K/'P01_manifest.sha256').read_text('utf8').splitlines()
 for line in manifest:
  if not line.strip():continue
  parts=line.split('  ',1)
  if len(parts)!=2 or sha(K/parts[1])!=parts[0]:errors.append('P01 manifest mismatch: '+line[:150])
 return errors,counts
if __name__=='__main__':
 bad,counts=check();print(json.dumps({'result':'FAIL' if bad else 'PASS','counts':counts,'errors':bad},ensure_ascii=False,indent=2));sys.exit(bool(bad))
