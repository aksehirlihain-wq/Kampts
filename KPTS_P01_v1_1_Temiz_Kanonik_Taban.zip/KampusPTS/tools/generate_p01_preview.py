#!/usr/bin/env python3
"""Read P01's exact frozen CSV schema and produce a nonauthoritative UI projection.
Keep all raw source rows, derive explicit UI labels only; no generated field records.
"""
from pathlib import Path
import csv,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
WEB=ROOT.parent
DATA=ROOT/'docs/p01/data'
SURVEY=['campuses.csv','facilities.csv','lanes.csv','devices.csv','network-links.csv','physical-evidence.csv','operating-metrics.csv','legal-entities.csv','paid-services.csv','financial-flows.csv','current-integrations.csv','open-findings.csv']
REGISTRY=['stakeholder-roster.csv','interview-questionnaire.csv','use-case-catalog.csv','nfr-discovery.csv','p01-requirement-evidence-plan.csv']

def read(name):
 with (DATA/name).open(encoding='utf-8-sig',newline='') as f:
  reader=csv.DictReader(f)
  return list(reader), reader.fieldnames or []

def generate():
 st,_=read('stakeholder-roster.csv')
 q,_=read('interview-questionnaire.csv')
 uc,_=read('use-case-catalog.csv')
 nf,_=read('nfr-discovery.csv')
 req,_=read('p01-requirement-evidence-plan.csv')
 survey={}
 for name in SURVEY:
  rows,fields=read(name)
  survey[name[:-4]]={'file':name,'fields':fields,'rowCount':len(rows),'status':'DATA_NOT_COLLECTED' if not rows else 'UNVERIFIED'}
 hashes={f'docs/p01/data/{n}':hashlib.sha256((DATA/n).read_bytes()).hexdigest() for n in sorted(SURVEY+REGISTRY)}
 result={
  'kind':'PREVIEW_ONLY',
  'provenance':'KampusPTS/docs/p01/data (P01 frozen reference schemas; UI-only derived aliases)',
  'status':'DESIGN_ONLY / DATA_NOT_COLLECTED',
  'gateStatus':{'G0':'NOT_APPROVED','G1':'NOT_STARTED','operationalFlags':'ALL_DISABLED','liveAccess':'LIVE_NO_GO'},
  'counts':{'registriesTotal':17,'stakeholders':len(st),'interviewQuestions':len(q),'useCases':len(uc),'nfrRecords':len(nf),'reqEvidenceMappings':len(req),'fieldSurveyRegistries':len(SURVEY)},
  'stakeholders':[dict(s,role_id=f'LIST-{i:03d}',role_name=s['stakeholder_role'],role_group=s['stakeholder_role'].split('/')[0],contact_person=s['assigned_name_or_department']) for i,s in enumerate(st,1)],
  'interviewQuestions':[dict(x,group_code=''.join(ch for ch in x['question_id'] if ch.isalpha()),question_text=x['question'],stakeholder_role=x['stakeholder'],topic=x['stakeholder'],required_evidence=x['expected_evidence'],status=x['answer_status'],evidence_ref=x['meeting_reference']) for x in q],
  'useCases':[dict(x,family=x['persona'],title=x['name'],primary_actor=x['persona'],trigger='UNKNOWN',evidence_target='EVIDENCE_PENDING',handover_phase='P03') for x in uc],
  'nfrDiscovery':[dict(x,category=x['area'],topic=x['area'],measurement_metric=x['needed_measurement'],discovery_method=x['measurement_method'],responsible_authority=x['owner_role']) for x in nf],
  'requirementEvidencePlan':[dict(x,title=x['deliverable'],evidence_target_type=x['evidence_target'],expected_document_or_artifact=x['source_form'],responsible_role=x['owner_role'],verification_method=x['acceptance_test'],current_status=x['evidence_status']) for x in req],
  'fieldSurveySchemas':survey,
  'hashes':hashes,
  'metadata':{'derivedFields':'Display aliases are generated from canonical values; they are not P01 CSV columns','realEvidenceCount':0}
 }
 return result
if __name__=='__main__':
 out=WEB/'src/data/p01-discovery.json';out.parent.mkdir(parents=True,exist_ok=True)
 out.write_text(json.dumps(generate(),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print('GENERATED P01 PREVIEW',out)
