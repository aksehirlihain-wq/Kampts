# P01 gerçek kanıt deposu
Bu teslimatta **hiçbir gerçek saha kanıtı yoktur**. Sadece EVD kabul şablonu `docs/p01/evidence-intake-template.md` içinde. Gerçek kanıt dosyaları SHA-256 ve paydaş doğrulaması ile kuruma ait güvenli depoda tutulmalıdır. Gerçek plaka/fotoğraf veya ağ sırrını dağıtılabilir ZIP'e eklemeyin.
