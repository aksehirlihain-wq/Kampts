import unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from validate_p01 import check
class TestP01Structure(unittest.TestCase):
    def test_design_only_structure(self):
        self.assertTrue(check())
