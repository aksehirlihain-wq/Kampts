import unittest,sys,csv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from audit_p01_canonical import check
from generate_p01_preview import generate,read
class TestP01Canonical(unittest.TestCase):
 def test_frozen_p00_and_p01(self):
  errors,c=check(); self.assertEqual(errors,[]); self.assertEqual((c['p00_reference'],c['p00_workspace']),(56,49)); self.assertEqual(c['p01_reference'],c['p01_expected']); self.assertEqual(c['p01_workspace'],c['p01_expected'])
 def test_original_schemas(self):
  a,fields=read('stakeholder-roster.csv'); self.assertEqual(fields,['stakeholder_role','assigned_name_or_department','responsibility','formal_authority_evidence','status']);self.assertEqual(len(a),14)
  q,_=read('interview-questionnaire.csv');self.assertEqual(q[0]['question_id'],'S01');self.assertEqual(len(q),32)
  uc,_=read('use-case-catalog.csv');self.assertEqual(uc[0]['name'],'Ziyaretçi aracı giriş');self.assertEqual(len(uc),32)
 def test_no_fake_data(self):
  obj=generate();self.assertEqual(obj['metadata']['realEvidenceCount'],0);self.assertEqual(obj['counts']['registriesTotal'],17);self.assertEqual(obj['gateStatus']['G1'],'NOT_STARTED')
if __name__=='__main__':unittest.main()
