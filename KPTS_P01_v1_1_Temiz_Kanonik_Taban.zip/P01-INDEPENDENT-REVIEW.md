# P01 Independent Review — 30 October 2026

## Findings from user-provided AI Studio export
- 48/56 P00 reference and 39/49 P00 working bytes match original; **18 SHA mismatches**.
- P01 CSV schemas: **0/17 match** original source headings.
- Original `audit_source_integrity.py` replaced; new script has no `audit()` function, yet P01 validator imports it.
- P01 validator raised **ImportError**; P00 validator reported **63 errors**; `unittest discover` failed.
- Export's own 17/17 and npm PASS claims are not accepted as independent evidence.

## Restoration
- Restored frozen P00 workspace and reference from independent v1.3 clean source.
- Restored P01 source and 17 exact CSV files from independent original P01 reference.
- Preserved the new P01 React preview as a noncanonical display layer and generated its data with explicit adapters.
- Wrote independent P00+P01 source SHA validator and regression tests.
- Original P01 design documents are retained; historical validations are reference-only.

## Limits
- No live services, physical gates, vendor API, payments, e-documents, legal approval or site survey executed.
- See actual test log and build status in accompanying `P01-test-results.txt`.
