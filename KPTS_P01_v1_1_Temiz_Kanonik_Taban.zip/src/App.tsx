import React, { useState, useMemo } from 'react';
import {
  Shield,
  CircleAlert,
  Files,
  ScanSearch,
  ShieldCheck,
  LayoutDashboard,
  FileLock2,
  Users,
  HelpCircle,
  Network,
  CreditCard,
  ListChecks,
  Activity,
  Download,
  Search,
  ExternalLink,
  ChevronRight,
  Sliders,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Building2,
  Cpu,
  Layers,
  FileText,
  Workflow
} from 'lucide-react';
import p00Data from './data/p00-canonical.json';
import p01Data from './data/p01-discovery.json';

type TabId =
  | 'p01-overview'
  | 'p01-stakeholders'
  | 'p01-campus'
  | 'p01-integration'
  | 'p01-financial'
  | 'p01-usecases'
  | 'p01-nfr'
  | 'p00-governance';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('p01-overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<string>('ALL');
  const [selectedUseCaseFamily, setSelectedUseCaseFamily] = useState<string>('ALL');
  const [isDemoDraftActive, setIsDemoDraftActive] = useState<boolean>(false);
  const [selectedDetail, setSelectedDetail] = useState<{
    type: 'question' | 'usecase' | 'stakeholder' | 'nfr' | 'model';
    data: any;
  } | null>(null);

  // Status strings
  const p00Status = 'P00 BASELINE: INDEPENDENT AUDIT REQUIRED';
  const p01Status = p01Data.status; // DESIGN_ONLY / DATA_NOT_COLLECTED
  const g0Status = 'G0 NOT_APPROVED';
  const g1Status = 'G1 NOT_STARTED';
  const liveStatus = 'LIVE NO-GO';

  // Filtered Questions
  const filteredQuestions = useMemo(() => {
    return p01Data.interviewQuestions.filter((q) => {
      const matchesGroup = selectedGroup === 'ALL' || q.group_code === selectedGroup;
      const qText = `${q.question_id} ${q.topic} ${q.question_text} ${q.stakeholder_role} ${q.required_evidence}`.toLocaleLowerCase('tr');
      const matchesSearch = qText.includes(searchQuery.toLocaleLowerCase('tr'));
      return matchesGroup && matchesSearch;
    });
  }, [searchQuery, selectedGroup]);

  // Filtered Use Cases
  const filteredUseCases = useMemo(() => {
    return p01Data.useCases.filter((uc) => {
      const matchesFamily = selectedUseCaseFamily === 'ALL' || uc.family === selectedUseCaseFamily;
      const text = `${uc.use_case_id} ${uc.title} ${uc.family} ${uc.primary_actor} ${uc.trigger}`.toLocaleLowerCase('tr');
      const matchesSearch = text.includes(searchQuery.toLocaleLowerCase('tr'));
      return matchesFamily && matchesSearch;
    });
  }, [searchQuery, selectedUseCaseFamily]);

  const useCaseFamilies = useMemo(() => {
    const set = new Set(p01Data.useCases.map((u) => u.family));
    return Array.from(set);
  }, []);

  // Export JSON handler
  const handleExportJSON = () => {
    const exportBlob = new Blob([JSON.stringify(p01Data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(exportBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `KampusPTS_P01_Discovery_Snapshot_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Export CSV handler (selected registry)
  const handleExportCSV = (registryName: string, items: any[]) => {
    if (!items || items.length === 0) return;
    const headers = Object.keys(items[0]);
    const csvContent = [
      headers.join(','),
      ...items.map((row) =>
        headers
          .map((field) => {
            const val = row[field] ?? '';
            return typeof val === 'string' && /[",\r\n]/.test(val) ? `"${val.replace(/"/g, '""')}"` : val;
          })
          .join(',')
      ),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `KampusPTS_${registryName}_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans antialiased">
      {/* Top Banner — Legal & Safety Boundary */}
      <div className="bg-[#1b2a32] text-slate-200 px-4 py-2 text-xs flex flex-wrap items-center justify-between gap-2 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
          <span className="font-medium tracking-wide">
            KAMPÜS PTS • P01 KURUMSAL VE SAHA KEŞFİ KONSOLU
          </span>
          <span className="text-slate-400">|</span>
          <span className="text-slate-300 font-mono text-[11px]">
            TASARIM ÖNİZLEMESİ — GERÇEK SAHA VE FİNANS İŞLEMİ YAPMAZ
          </span>
        </div>
        <div className="flex items-center gap-2 text-[11px] font-mono">
          <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300">
            P00 56/49: SEE AUDIT REPORT
          </span>
        </div>
      </div>

      {/* Main Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-bold text-base shadow-sm">
              PTS
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-bold tracking-tight text-slate-900">
                  Kampüs PTS — Gelir Yönetim Platformu
                </h1>
                <span className="text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md font-semibold">
                  P01 Keşif
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Kanonik P00 Anayasası & P01 Saha/Kurumsal Keşif Çalışma Alanı (Stitch v3)
              </p>
            </div>
          </div>

          {/* Epistemic Status Badges */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span
              title="P00 kaynak eşitliği çalışma alanında bağımsız Python audit ile doğrulanmalıdır"
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              {p00Status}
            </span>
            <span
              title="Fiili saha ve kurum verisi henüz toplanmadı, kütükler tasarım şablonudur"
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              {p01Status}
            </span>
            <span
              title="G0 kurumsal sponsor imzası henüz bulunmuyor (BLK-008)"
              className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-semibold bg-red-50 text-red-800 border border-red-200"
            >
              <XCircle className="w-3.5 h-3.5 text-red-600" />
              {g0Status}
            </span>
            <span
              title="G1 kapısı P01–P04 ortak kapısıdır; P01 tamamlanmasıyla onaylanmaz"
              className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200"
            >
              <CircleAlert className="w-3.5 h-3.5 text-slate-500" />
              {g1Status}
            </span>
            <span
              title="Canlı bariyer, ödeme ve e-fatura servisleri kesinlikle kapalıdır"
              className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-bold bg-slate-900 text-white"
            >
              <FileLock2 className="w-3.5 h-3.5 text-amber-400" />
              {liveStatus}
            </span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-slate-100 flex items-center justify-between overflow-x-auto">
          <nav className="flex gap-1 py-1">
            <button
              onClick={() => {
                setActiveTab('p01-overview');
                setSearchQuery('');
              }}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'p01-overview'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              Genel Durum (P01)
            </button>

            <button
              onClick={() => {
                setActiveTab('p01-stakeholders');
                setSearchQuery('');
              }}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'p01-stakeholders'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              Paydaşlar ve Görüşmeler ({p01Data.counts.interviewQuestions})
            </button>

            <button
              onClick={() => {
                setActiveTab('p01-campus');
                setSearchQuery('');
              }}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'p01-campus'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              Kampüs & Cihaz Envanteri (7 Kütük)
            </button>

            <button
              onClick={() => {
                setActiveTab('p01-integration');
                setSearchQuery('');
              }}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'p01-integration'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              Entegrasyon Keşfi (ASManager/LPR)
            </button>

            <button
              onClick={() => {
                setActiveTab('p01-financial');
                setSearchQuery('');
              }}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'p01-financial'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5" />
              Mali & Hukuki (DEC-001 A/B/C/D)
            </button>

            <button
              onClick={() => {
                setActiveTab('p01-usecases');
                setSearchQuery('');
              }}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'p01-usecases'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <ListChecks className="w-3.5 h-3.5" />
              İş Senaryoları (UC-001..032)
            </button>

            <button
              onClick={() => {
                setActiveTab('p01-nfr');
                setSearchQuery('');
              }}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'p01-nfr'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              NFR & Kanıt Planı (REQ-005..013)
            </button>

            <button
              onClick={() => {
                setActiveTab('p00-governance');
                setSearchQuery('');
              }}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'p00-governance'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              P00 Yönetişim & İlkeler
            </button>
          </nav>

          {/* Quick Actions */}
          <div className="flex items-center gap-2 pl-4 py-1 shrink-0">
            <button
              onClick={() => setIsDemoDraftActive(!isDemoDraftActive)}
              className={`flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-md border font-medium transition-colors ${
                isDemoDraftActive
                  ? 'bg-amber-100 border-amber-300 text-amber-900'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
              title="Sentetik örnek verileri geçici oturumda gösterir; kanonik dosyaları değiştirmez"
            >
              <Sliders className="w-3 h-3 text-amber-600" />
              {isDemoDraftActive ? 'Sentetik Demo Aktif' : 'Sentetik Demo Modu'}
            </button>

            <button
              onClick={handleExportJSON}
              className="flex items-center gap-1 px-2.5 py-1 text-xs rounded-md bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 transition-colors shadow-2xs"
              title="P01 Keşif JSON Anlık Görüntüsünü İndir (İstemci Tarafı)"
            >
              <Download className="w-3 h-3 text-slate-500" />
              JSON Dışa Aktar
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* TAB 1: P01 OVERVIEW */}
        {activeTab === 'p01-overview' && (
          <div className="space-y-6">
            {/* Hero / State Card */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
                <div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Aşama Durumu &middot; P01 — Kurumsal ve Saha Keşfi
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 mt-1">
                    Keşif Çalışma Alanı ve Veri Kütükleri
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-3xl">
                    P00 kanonik çekirdeği bozulmadan P01 keşif safhası için 17 CSV kütüğü, 14 paydaş rolü,
                    32 görüşme sorusu, 32 iş senaryosu ve 16 NFR ölçüm alanı yapılandırılmıştır.
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="text-xs text-slate-400 font-mono">Çıkış Kapısı</div>
                    <div className="text-sm font-bold text-slate-800">G1 Ortak Kapısı</div>
                    <div className="text-[11px] text-amber-700 font-medium">P01–P04 Kapsamı</div>
                  </div>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-5">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60">
                  <div className="text-[11px] font-medium text-slate-500">CSV Kütükleri</div>
                  <div className="text-2xl font-bold text-slate-900 mt-1">
                    {p01Data.counts.registriesTotal}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">docs/p01/data/</div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60">
                  <div className="text-[11px] font-medium text-slate-500">Paydaş Rolleri</div>
                  <div className="text-2xl font-bold text-slate-900 mt-1">
                    {p01Data.counts.stakeholders}
                  </div>
                  <div className="text-[10px] text-amber-600 font-medium mt-0.5">
                    14/14 TO_ASSIGN
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60">
                  <div className="text-[11px] font-medium text-slate-500">Görüşme Soruları</div>
                  <div className="text-2xl font-bold text-slate-900 mt-1">
                    {p01Data.counts.interviewQuestions}
                  </div>
                  <div className="text-[10px] text-amber-600 font-medium mt-0.5">
                    32/32 NOT_COLLECTED
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60">
                  <div className="text-[11px] font-medium text-slate-500">İş Senaryoları</div>
                  <div className="text-2xl font-bold text-slate-900 mt-1">
                    {p01Data.counts.useCases}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">UC-001..UC-032 (P03)</div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60">
                  <div className="text-[11px] font-medium text-slate-500">NFR Ölçüm Alanı</div>
                  <div className="text-2xl font-bold text-slate-900 mt-1">
                    {p01Data.counts.nfrRecords}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">16 Metrik Hedefi</div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60">
                  <div className="text-[11px] font-medium text-slate-500">REQ-EVD Eşlemesi</div>
                  <div className="text-2xl font-bold text-slate-900 mt-1">
                    {p01Data.counts.reqEvidenceMappings}
                  </div>
                  <div className="text-[10px] text-amber-600 font-medium mt-0.5">
                    REQ-005..REQ-013
                  </div>
                </div>
              </div>
            </div>

            {/* Core Architectural Invariants in P01 */}
            <div className="grid md:grid-cols-3 gap-4">
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs">
                <div className="flex items-center gap-2 text-slate-900 font-semibold text-sm">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  K-01: Otorite Ayrılığı
                </div>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  <strong>GV-ASManager</strong> fiziksel kapı ve bariyer yetkisinin tek otoritesidir.{' '}
                  <strong>Kampüs PTS</strong> mali haklar ve seans otoritesidir. Mali abonelik satın
                  alınması, fiziksel teyit (ACK) gelmeden kapı açamaz.
                </p>
                <div className="mt-3 font-mono text-[11px] text-slate-500 bg-slate-50 px-2.5 py-1.5 rounded border border-slate-200">
                  PLATE_RECOGNIZED &ne; PASSAGE_CONFIRMED &ne; GATE_ACK
                </div>
              </div>

              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs">
                <div className="flex items-center gap-2 text-slate-900 font-semibold text-sm">
                  <Cpu className="w-4 h-4 text-blue-600" />
                  K-02: Marka Bağımsızlığı
                </div>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Mevcut GeoVision altyapısı (ASManager 6.3.0 ve GV-LPR2812-DL) yanında standart{' '}
                  <strong>ONVIF Profile M</strong> ve HTTP POST desteğiyle diğer kamera üreticilerine
                  açık mimari garanti altına alınmıştır.
                </p>
                <div className="mt-3 font-mono text-[11px] text-slate-500 bg-slate-50 px-2.5 py-1.5 rounded border border-slate-200">
                  IVendorLprAdapter: Tekil PlateObservation
                </div>
              </div>

              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs">
                <div className="flex items-center gap-2 text-slate-900 font-semibold text-sm">
                  <FileLock2 className="w-4 h-4 text-amber-600" />
                  K-12: Test ve Kanıt Doğruluğu
                </div>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  İmzalı kurumsal tutanak veya saha PoC kaydı olmadan hiçbir gereksinim veya karar{' '}
                  <strong>VERIFIED</strong> sayılamaz.{' '}
                  <span className="font-mono text-slate-700">UNKNOWN &ne; FALSE</span>,{' '}
                  <span className="font-mono text-slate-700">NOT_RUN &ne; PASS</span>.
                </p>
                <div className="mt-3 font-mono text-[11px] text-amber-800 bg-amber-50 px-2.5 py-1.5 rounded border border-amber-200">
                  CAPTURED &ne; SETTLED | ACTIVE &ne; VERIFIED_ACTIVE
                </div>
              </div>
            </div>

            {/* 17 Registry Summary Matrix */}
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
              <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    P01 Kayıt Kütükleri Durum Matrisi (17 CSV)
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    KampusPTS/docs/p01/data/ dizinindeki gerçek dosya durumları
                  </p>
                </div>
                <button
                  onClick={() => handleExportCSV('All_Registries_Index', [p01Data.counts])}
                  className="text-xs text-slate-600 hover:text-slate-900 flex items-center gap-1 font-medium"
                >
                  <Download className="w-3.5 h-3.5" />
                  Özeti İndir
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-slate-100">
                {/* Column 1: Saha / Tesis / Cihaz */}
                <div className="p-4">
                  <div className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-3 flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-slate-500" />
                    Saha, Tesis ve Cihaz (7)
                  </div>
                  <ul className="space-y-2 text-xs">
                    {[
                      { name: 'campuses.csv', desc: 'Yerleşkeler', rows: 0 },
                      { name: 'facilities.csv', desc: 'Otopark / Tesisler', rows: 0 },
                      { name: 'lanes.csv', desc: 'Giriş-Çıkış Şeritleri', rows: 0 },
                      { name: 'devices.csv', desc: 'Kamera, Bariyer, Loop', rows: 0 },
                      { name: 'network-links.csv', desc: 'VLAN ve Ağ Bağlantıları', rows: 0 },
                      { name: 'physical-evidence.csv', desc: 'Geçiş Kanıtı Kayıtları', rows: 0 },
                      { name: 'operating-metrics.csv', desc: 'Pik Saat ve Sayaç Verisi', rows: 0 },
                    ].map((item) => (
                      <li
                        key={item.name}
                        className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100"
                      >
                        <div>
                          <div className="font-mono font-medium text-slate-800">{item.name}</div>
                          <div className="text-[11px] text-slate-500">{item.desc}</div>
                        </div>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-slate-200 text-slate-700 font-mono">
                          0 SATIR (ŞABLON)
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Column 2: Mali / Entegrasyon */}
                <div className="p-4">
                  <div className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-3 flex items-center gap-1.5">
                    <CreditCard className="w-3.5 h-3.5 text-slate-500" />
                    Mali ve Entegrasyon (4)
                  </div>
                  <ul className="space-y-2 text-xs">
                    {[
                      { name: 'legal-entities.csv', desc: 'Tüzel Kişilikler', rows: 0 },
                      { name: 'paid-services.csv', desc: 'Ücretli Hizmetler', rows: 0 },
                      { name: 'financial-flows.csv', desc: '12 Adımlı Finans Akışı', rows: 0 },
                      { name: 'current-integrations.csv', desc: 'Mevcut Sistemler', rows: 0 },
                    ].map((item) => (
                      <li
                        key={item.name}
                        className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100"
                      >
                        <div>
                          <div className="font-mono font-medium text-slate-800">{item.name}</div>
                          <div className="text-[11px] text-slate-500">{item.desc}</div>
                        </div>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-slate-200 text-slate-700 font-mono">
                          0 SATIR (ŞABLON)
                        </span>
                      </li>
                    ))}
                  </ul>

                  <div className="mt-4 p-3 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-900 leading-relaxed">
                    <strong>Hukuki Kısıt:</strong> DEC-001 (A/B/C/D modeli) ve DEC-027 (otopark dışı
                    ücret yetkisi) karara bağlanmadıkça gelir kütüklerine fiili kayıt girilemez.
                  </div>
                </div>

                {/* Column 3: Yönetişim / Keşif */}
                <div className="p-4">
                  <div className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-3 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-slate-500" />
                    Yönetişim, Görüşme ve Keşif (6)
                  </div>
                  <ul className="space-y-2 text-xs">
                    <li className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                      <div>
                        <div className="font-mono font-medium text-slate-800">
                          stakeholder-roster.csv
                        </div>
                        <div className="text-[11px] text-slate-500">14 Paydaş Rolü</div>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-mono">
                        14 TO_ASSIGN
                      </span>
                    </li>
                    <li className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                      <div>
                        <div className="font-mono font-medium text-slate-800">
                          interview-questionnaire.csv
                        </div>
                        <div className="text-[11px] text-slate-500">32 Ciltli Görüşme Sorusu</div>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-mono">
                        32 NOT_COLLECTED
                      </span>
                    </li>
                    <li className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                      <div>
                        <div className="font-mono font-medium text-slate-800">
                          use-case-catalog.csv
                        </div>
                        <div className="text-[11px] text-slate-500">32 Senaryo Ailesi</div>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-blue-100 text-blue-800 font-mono">
                        32 UC (P03 HANDOVER)
                      </span>
                    </li>
                    <li className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                      <div>
                        <div className="font-mono font-medium text-slate-800">
                          nfr-discovery.csv
                        </div>
                        <div className="text-[11px] text-slate-500">16 Ölçüm & Belirsizlik Alanı</div>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-purple-100 text-purple-800 font-mono">
                        16 TO_DEFINE
                      </span>
                    </li>
                    <li className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                      <div>
                        <div className="font-mono font-medium text-slate-800">
                          p01-requirement-evidence-plan.csv
                        </div>
                        <div className="text-[11px] text-slate-500">REQ-005..013 Kanıt Planı</div>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-mono">
                        9 EVIDENCE_PENDING
                      </span>
                    </li>
                    <li className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                      <div>
                        <div className="font-mono font-medium text-slate-800">open-findings.csv</div>
                        <div className="text-[11px] text-slate-500">Keşif Açık Bulguları</div>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-200 text-slate-700 font-mono">
                        0 SATIR (ŞABLON)
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: STAKEHOLDERS & INTERVIEWS */}
        {activeTab === 'p01-stakeholders' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  Paydaşlar ve Kurumsal Görüşme Soru Seti
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  14 paydaş rolü (TO_ASSIGN) ve 32 kodlu görüşme sorusu (NOT_COLLECTED)
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Soru ID, rol veya konu ara..."
                    className="pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-slate-400 w-52 sm:w-64"
                  />
                </div>

                <button
                  onClick={() => handleExportCSV('Gorusme_Sorulari', p01Data.interviewQuestions)}
                  className="flex items-center gap-1 px-3 py-1.5 text-xs rounded-lg bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5 text-slate-500" />
                  CSV İndir
                </button>
              </div>
            </div>

            {/* 14 Stakeholders Cards Horizon */}
            <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs">
              <div className="flex items-center justify-between mb-3">
                <div className="text-xs font-bold text-slate-700 uppercase tracking-wide">
                  14 Kurumsal Paydaş Rolü (stakeholder-roster.csv)
                </div>
                <span className="text-[11px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                  Tümü TO_ASSIGN (Şahıs atanmadı)
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2">
                {p01Data.stakeholders.map((s) => (
                  <div
                    key={s.role_id}
                    onClick={() => setSelectedDetail({ type: 'stakeholder', data: s })}
                    className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 hover:border-slate-300 cursor-pointer transition-all text-left"
                  >
                    <div className="flex items-center justify-between text-[10px] font-mono text-slate-500">
                      <span>{s.role_id}</span>
                      <span className="text-amber-700 font-bold">ATANACAK</span>
                    </div>
                    <div className="font-semibold text-xs text-slate-800 mt-1 line-clamp-1" title={s.role_name}>
                      {s.role_name}
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5 truncate">{s.role_group}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Filter Buttons for Questions */}
            <div className="flex flex-wrap items-center gap-1.5">
              {[
                { code: 'ALL', label: 'Tümü (32)' },
                { code: 'S', label: 'Sponsor / Rektörlük (3)' },
                { code: 'B', label: 'BİDB / Altyapı (4)' },
                { code: 'G', label: 'Güvenlik / Nizamiye (5)' },
                { code: 'I', label: 'İşletme / Tesis (4)' },
                { code: 'M', label: 'Mali İşler / Döner Sermaye (5)' },
                { code: 'H', label: 'Hukuk / KVKK (4)' },
                { code: 'E', label: 'ERP / Entegratör (2)' },
                { code: 'T', label: 'Teknoloji / Üretici (3)' },
                { code: 'F', label: 'İSG / İç Denetim (2)' },
              ].map((g) => (
                <button
                  key={g.code}
                  onClick={() => setSelectedGroup(g.code)}
                  className={`px-2.5 py-1 text-xs rounded-md transition-colors ${
                    selectedGroup === g.code
                      ? 'bg-slate-900 text-white font-medium shadow-2xs'
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {g.label}
                </button>
              ))}
            </div>

            {/* Questions Table */}
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
                    <tr>
                      <th className="py-3 px-4">ID</th>
                      <th className="py-3 px-4">Grup & Rol</th>
                      <th className="py-3 px-4">Konu / Başlık</th>
                      <th className="py-3 px-4">Soru Metni</th>
                      <th className="py-3 px-4">Beklenen Kanıt Belgesi</th>
                      <th className="py-3 px-4">Durum</th>
                      <th className="py-3 px-4 text-right">İşlem</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredQuestions.map((q) => (
                      <tr key={q.question_id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-slate-900">{q.question_id}</td>
                        <td className="py-3 px-4">
                          <span className="inline-block px-1.5 py-0.5 rounded bg-slate-100 font-mono text-[10px] text-slate-700 mr-1.5">
                            {q.group_code}
                          </span>
                          <span className="text-slate-600">{q.stakeholder_role}</span>
                        </td>
                        <td className="py-3 px-4 font-medium text-slate-800">{q.topic}</td>
                        <td className="py-3 px-4 text-slate-600 max-w-md">{q.question_text}</td>
                        <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                          {q.required_evidence}
                        </td>
                        <td className="py-3 px-4">
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                            {q.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => setSelectedDetail({ type: 'question', data: q })}
                            className="text-xs font-semibold text-slate-700 hover:text-slate-900 hover:underline inline-flex items-center gap-0.5"
                          >
                            Detay
                            <ChevronRight className="w-3 h-3" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: CAMPUS & DEVICE INVENTORY */}
        {activeTab === 'p01-campus' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  Kampüs, Tesis, Şerit ve Cihaz Envanteri (7 Kütük)
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Fiziksel saha varlık hiyerarşisi ve sensör ayrıştırma modeli
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs bg-slate-100 text-slate-700 px-3 py-1 rounded-md font-mono border border-slate-200">
                  KÜTÜK DURUMU: DATA_NOT_COLLECTED (0 SATIR)
                </span>
              </div>
            </div>

            {/* Physical Hierarchy Architecture Diagram */}
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs">
              <div className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-3 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-slate-500" />
                Varlık Hiyerarşisi & İletişim Mimarisi
              </div>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-center">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="w-8 h-8 rounded-lg bg-slate-200 text-slate-700 font-bold mx-auto flex items-center justify-center text-xs mb-2">
                    1
                  </div>
                  <div className="font-bold text-sm text-slate-900">Kampüs (Campus)</div>
                  <div className="text-xs text-slate-500 mt-1">Coğrafi Yerleşke (Merkez, Tıp, Doğu)</div>
                  <div className="font-mono text-[11px] text-slate-400 mt-2">campuses.csv</div>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="w-8 h-8 rounded-lg bg-slate-200 text-slate-700 font-bold mx-auto flex items-center justify-center text-xs mb-2">
                    2
                  </div>
                  <div className="font-bold text-sm text-slate-900">Tesis / Otopark (Facility)</div>
                  <div className="text-xs text-slate-500 mt-1">Açık/Kapalı Alan veya Nizamiye</div>
                  <div className="font-mono text-[11px] text-slate-400 mt-2">facilities.csv</div>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="w-8 h-8 rounded-lg bg-slate-200 text-slate-700 font-bold mx-auto flex items-center justify-center text-xs mb-2">
                    3
                  </div>
                  <div className="font-bold text-sm text-slate-900">Şerit (Lane)</div>
                  <div className="text-xs text-slate-500 mt-1">Giriş / Çıkış Koridoru</div>
                  <div className="font-mono text-[11px] text-slate-400 mt-2">lanes.csv</div>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="w-8 h-8 rounded-lg bg-slate-200 text-slate-700 font-bold mx-auto flex items-center justify-center text-xs mb-2">
                    4
                  </div>
                  <div className="font-bold text-sm text-slate-900">Cihazlar (Devices)</div>
                  <div className="text-xs text-slate-500 mt-1">LPR Kamera, Bariyer, Loop, Fotosel</div>
                  <div className="font-mono text-[11px] text-slate-400 mt-2">devices.csv</div>
                </div>
              </div>
            </div>

            {/* Tri-Event Sensor Invariant */}
            <div className="bg-amber-50/60 rounded-xl p-5 border border-amber-200">
              <div className="flex items-center gap-2 text-amber-900 font-bold text-sm">
                <AlertTriangle className="w-4 h-4 text-amber-700" />
                Üçlü Olay Ayrıştırma Zorunluluğu (Tri-Event Model)
              </div>
              <p className="text-xs text-amber-900 mt-1.5 leading-relaxed">
                Kamera plaka okuması tek başına aracın geçtiğini veya bariyerin açıldığını kanıtlamaz.
                Sistem aşağıdaki 3 olayı kesin olarak ayrıştırır:
              </p>
              <div className="grid md:grid-cols-3 gap-3 mt-3">
                <div className="bg-white p-3 rounded-lg border border-amber-200/80">
                  <div className="font-mono font-bold text-xs text-slate-800">1. PlateObservation</div>
                  <p className="text-[11px] text-slate-600 mt-1">
                    Kamera görüntüyü işledi ve plaka metnini üretti. Bariyer henüz açılmadı.
                  </p>
                </div>
                <div className="bg-white p-3 rounded-lg border border-amber-200/80">
                  <div className="font-mono font-bold text-xs text-slate-800">2. GateAck</div>
                  <p className="text-[11px] text-slate-600 mt-1">
                    Kontrolör rölesi tetiklendi ve bariyer kolu dik konuma ulaştı.
                  </p>
                </div>
                <div className="bg-white p-3 rounded-lg border border-amber-200/80">
                  <div className="font-mono font-bold text-xs text-slate-800">3. PassageEvidence</div>
                  <p className="text-[11px] text-slate-600 mt-1">
                    Manyetik loop ve fotosel aracın fiziksel olarak şeritten çıktığını teyit etti.
                  </p>
                </div>
              </div>
            </div>

            {/* Empty Field Registries Notice or Synthetic Demo */}
            {!isDemoDraftActive ? (
              <div className="bg-white rounded-xl p-8 border border-slate-200 text-center shadow-2xs">
                <Building2 className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <h3 className="text-sm font-bold text-slate-800">Henüz Saha Verisi Toplanmadı</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 leading-relaxed">
                  P01 kurumsal keşif ilkeleri uyarınca sahte kampus adı, cihaz IP&apos;si veya şerit numarası
                  üretilmemiştir. 7 saha kütüğü (campuses, facilities, lanes, devices, network-links,
                  physical-evidence, operating-metrics) sıfır satır ile fiili saha gezisi girdisini beklemektedir.
                </p>
                <div className="mt-4 flex justify-center gap-3">
                  <button
                    onClick={() => setIsDemoDraftActive(true)}
                    className="px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-medium hover:bg-slate-800 transition-colors shadow-2xs"
                  >
                    Sentetik Örnekleri Görüntüle (DEMO_DRAFT_ONLY)
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-900 flex items-center justify-between">
                  <div>
                    <strong>Sentetik Saha Görünümü Aktif:</strong> Bu veriler tamamen sentetik olup{' '}
                    <code className="font-mono">docs/p01/examples/SYNTHETIC-EXAMPLE-ONLY.md</code>{' '}
                    belgesinden görselleştirilmiştir.
                  </div>
                  <button
                    onClick={() => setIsDemoDraftActive(false)}
                    className="text-xs text-amber-900 underline font-semibold"
                  >
                    Kapat
                  </button>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs">
                    <div className="text-xs font-bold text-slate-800 uppercase tracking-wide mb-2">
                      Sentetik Yerleşke & Otopark (KMP-DEMO-01)
                    </div>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between py-1 border-b border-slate-100">
                        <span className="text-slate-500">Yerleşke Adı:</span>
                        <span className="font-semibold">Sentetik Anadolu Yerleşkesi</span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-100">
                        <span className="text-slate-500">Tesis Kodu:</span>
                        <span className="font-mono">FAC-DEMO-01 (Kütüphane Otoparkı)</span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-100">
                        <span className="text-slate-500">Kapasite:</span>
                        <span>120 Araç</span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-100">
                        <span className="text-slate-500">Giriş Şeridi:</span>
                        <span className="font-mono">LANE-DEMO-01 (Kuzey Kapısı)</span>
                      </div>
                      <div className="flex justify-between py-1">
                        <span className="text-slate-500">Çıkış Şeridi:</span>
                        <span className="font-mono">LANE-DEMO-02 (Kuzey Kapısı)</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs">
                    <div className="text-xs font-bold text-slate-800 uppercase tracking-wide mb-2">
                      Sentetik Şerit Donanımı (LANE-DEMO-01)
                    </div>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between py-1 border-b border-slate-100">
                        <span className="text-slate-500">LPR Kamera:</span>
                        <span className="font-semibold">GV-LPR2812-DL (Demo Firmware v1.12)</span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-100">
                        <span className="text-slate-500">Bariyer Motoru:</span>
                        <span>BFT Moovi 30 (Kollu)</span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-100">
                        <span className="text-slate-500">Manyetik Loop:</span>
                        <span>Çift Loop (Yaklaşma + Emniyet/Ayrılma)</span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-100">
                        <span className="text-slate-500">Fotosel Emniyeti:</span>
                        <span className="text-emerald-700 font-semibold">Aktif (Çift Işınlı)</span>
                      </div>
                      <div className="flex justify-between py-1">
                        <span className="text-slate-500">Ağ Bölgesi:</span>
                        <span className="font-mono text-slate-600">VLAN-100 (Kapalı Güvenlik Ağı)</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 4: INTEGRATION DISCOVERY */}
        {activeTab === 'p01-integration' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                Donanım ve Entegrasyon Kanalı Keşfi
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                GeoVision GV-ASManager 6.3.0, GV-LPR kameralar ve marka bağımsız ONVIF Profile M
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {/* ASManager Card */}
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-800 flex items-center justify-center font-bold text-xs">
                      GV
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-900">
                        GeoVision GV-ASManager 6.3.0
                      </h3>
                      <div className="text-[11px] text-slate-500">Fiziksel Erişim Otoritesi</div>
                    </div>
                  </div>
                  <span className="text-[11px] font-mono font-bold bg-amber-50 text-amber-800 px-2.5 py-1 rounded border border-amber-200">
                    STATUS: UNKNOWN
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg text-xs space-y-2 border border-slate-100">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Webhook / Event Push Desteği:</span>
                    <span className="font-semibold text-amber-800">UNKNOWN (Doğrulanmadı)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Plaka Beyaz Liste API:</span>
                    <span className="font-semibold text-amber-800">UNKNOWN (Doğrulanmadı)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Veritabanına Doğrudan SQL:</span>
                    <span className="font-bold text-red-700">KESİNLİKLE YASAK</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">İlişkili Blokaj:</span>
                    <span className="font-mono text-slate-800">BLK-003, BLK-004</span>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  ASManager 6.3.0 yazılımının belirli bir API endpoint&apos;ini desteklediği üretici teknik
                  şartnamesi veya ağ analiz kanıtı olmadan iddia edilemez. P02 PoC safhasında izole test
                  ortamında sınanacaktır.
                </p>
              </div>

              {/* Vendor Agnostic / ONVIF Card */}
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center font-bold text-xs">
                      ONVIF
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-900">
                        Marka Bağımsız LPR ve Standartlar
                      </h3>
                      <div className="text-[11px] text-slate-500">K-02 Değişmezi</div>
                    </div>
                  </div>
                  <span className="text-[11px] font-mono font-bold bg-blue-50 text-blue-800 px-2.5 py-1 rounded border border-blue-200">
                    DESIGN_ONLY
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg text-xs space-y-2 border border-slate-100">
                  <div className="flex justify-between">
                    <span className="text-slate-500">ONVIF Profile M Uyumu:</span>
                    <span className="font-semibold text-slate-800">Şartnameye Eklendi</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Kamera HTTP POST / MQTT:</span>
                    <span className="font-semibold text-slate-800">Normalizasyon Hazır</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Vendor Kilitlenmesi (Lock-in):</span>
                    <span className="font-semibold text-emerald-700">Engellendi</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Adaptör Deseni:</span>
                    <span className="font-mono text-slate-800">IVendorLprAdapter</span>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  Kampüs PTS, kamera üreticisinden bağımsız bir olay motoruna sahiptir. Sahadaki GeoVision
                  kameralar değiştirildiğinde veya farklı marka eklendiğinde merkezi sistem yeniden
                  kodlanmaz.
                </p>
              </div>
            </div>

            {/* Offline & Queue Resilience Architecture */}
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs">
              <div className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-2 flex items-center gap-1.5">
                <Workflow className="w-4 h-4 text-slate-500" />
                Ağ Kesintisi ve Offline Tamponlama Mimarisi (NFR-006 / NFR-007)
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Merkezi sunucu veya kampüs omurga ağında kesinti yaşandığında, şerit bilgisayarları (Edge)
                yerel SQLite veritabanına olayları tamponlar. Ağ tekrar bağlandığında{' '}
                <code className="font-mono text-slate-800 font-semibold">IdempotencyKey</code> ile
                merkeze aktarılır; çift kayıt oluşması önlenir.
              </p>
            </div>
          </div>
        )}

        {/* TAB 5: FINANCIAL & LEGAL DISCOVERY */}
        {activeTab === 'p01-financial' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  Mali Süreç, Gelir Sahibi ve Hukuk Keşfi
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  DEC-001 (A/B/C/D İşletme Modelleri), DEC-027 Yetkisi ve 12 Adımlı Finans Döngüsü
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs bg-amber-50 text-amber-800 px-3 py-1 rounded-md font-mono border border-amber-200 font-semibold">
                  DEC-001: DECISION_REQUIRED (BLK-001)
                </span>
              </div>
            </div>

            {/* DEC-001 4 Models Grid */}
            <div className="grid md:grid-cols-4 gap-3">
              {[
                {
                  id: 'MODEL_A',
                  title: 'Model A: Üniversite',
                  sub: 'Genel Bütçe Geliri',
                  desc: 'Gelir doğrudan üniversite bütçesine girer. Fatura kesilmez, muhasebe mutemet alındısı verilir. KDV muafiyeti olabilir.',
                  vat: 'Muaf / Belirsiz',
                  merchant: 'Rektörlük',
                  status: 'OPSİYON',
                },
                {
                  id: 'MODEL_B',
                  title: 'Model B: Döner Sermaye',
                  sub: 'İktisadi İşletme Geliri',
                  desc: 'Gelir Döner Sermaye Saymanlığında toplanır. Ticari e-Fatura / e-Arşiv faturası düzenlenir, %20 KDV uygulanır.',
                  vat: '%20 KDV',
                  merchant: 'Döner Sermaye',
                  status: 'OPSİYON',
                },
                {
                  id: 'MODEL_C',
                  title: 'Model C: Özel İşletmeci',
                  sub: 'Kiracı / İhale Yüklenicisi',
                  desc: 'Otopark özel şirkete kiralanmıştır. Sanal POS ve fatura şirkete aittir; üniversite kira veya ciro payı alır.',
                  vat: 'Şirket Mevzuatı',
                  merchant: 'Özel İşletmeci',
                  status: 'OPSİYON',
                },
                {
                  id: 'MODEL_D',
                  title: 'Model D: Çoklu Tüzel Kişilik',
                  sub: 'Hibrit Gelir Paylaşımı',
                  desc: 'Farklı otoparklar farklı tüzel kişiliklerdedir. Çoklu sanal POS, dinamik split ve virman mutabakatı gerektirir.',
                  vat: 'Karma Tarife',
                  merchant: 'Çoklu Merchant',
                  status: 'OPSİYON',
                },
              ].map((m) => (
                <div
                  key={m.id}
                  onClick={() => setSelectedDetail({ type: 'model', data: m })}
                  className="bg-white rounded-xl p-4 border border-slate-200 hover:border-slate-300 cursor-pointer transition-all shadow-2xs space-y-2"
                >
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-mono font-bold text-slate-500">{m.id}</span>
                    <span className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-semibold">
                      {m.status}
                    </span>
                  </div>
                  <h4 className="font-bold text-sm text-slate-900">{m.title}</h4>
                  <div className="text-[11px] font-medium text-slate-500">{m.sub}</div>
                  <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed mt-1">
                    {m.desc}
                  </p>
                  <div className="pt-2 border-t border-slate-100 text-[11px] space-y-1 text-slate-500">
                    <div>KDV: <span className="font-semibold text-slate-800">{m.vat}</span></div>
                    <div>Merchant: <span className="font-semibold text-slate-800">{m.merchant}</span></div>
                  </div>
                </div>
              ))}
            </div>

            {/* 12-Step Financial Lifecycle Diagram */}
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs">
              <div className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-3 flex items-center justify-between">
                <span>12 Adımlı Finansal Süreç Yaşam Döngüsü (financial-flows.csv)</span>
                <span className="text-[11px] font-mono text-slate-500">
                  CAPTURED &ne; SETTLED
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 lg:grid-cols-12 gap-1.5 text-center text-xs">
                {[
                  { step: '1', name: 'PlateObservation', desc: 'Plaka Okuma' },
                  { step: '2', name: 'PassageEvidence', desc: 'Geçiş Kanıtı' },
                  { step: '3', name: 'ParkingSession', desc: 'Seans Açılışı' },
                  { step: '4', name: 'Quote', desc: 'Ücret Teklifi' },
                  { step: '5', name: 'Charge', desc: 'Borç Tahakkuku' },
                  { step: '6', name: 'PaymentIntent', desc: 'Ödeme İsteği' },
                  { step: '7', name: 'PaymentTransaction', desc: '3D POS Provizyon' },
                  { step: '8', name: 'ProviderSettlement', desc: 'Banka Fon Takası' },
                  { step: '9', name: 'Invoice', desc: 'e-Belge (GİB)' },
                  { step: '10', name: 'LedgerEntry', desc: 'Yevmiye Taslağı' },
                  { step: '11', name: 'ERPPosting', desc: 'ERP Muhasebe' },
                  { step: '12', name: 'Reconciliation', desc: 'Gece Mutabakatı' },
                ].map((s) => (
                  <div
                    key={s.step}
                    className="p-2 rounded-lg bg-slate-50 border border-slate-100 flex flex-col justify-between"
                  >
                    <div className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 font-bold mx-auto text-[10px] flex items-center justify-center">
                      {s.step}
                    </div>
                    <div className="font-mono text-[10px] font-bold text-slate-800 mt-1 truncate" title={s.name}>
                      {s.name}
                    </div>
                    <div className="text-[9px] text-slate-400 mt-0.5">{s.desc}</div>
                  </div>
                ))}
              </div>

              <div className="mt-4 p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600 leading-relaxed">
                <strong>Finansal Ayrım Kuralı:</strong> Bankadan provizyon alınması (CAPTURED), paranın
                üniversite veya döner sermaye hesabına geçtiği (SETTLED) anlamına gelmez. Benzer şekilde
                mali bir aboneliğin ödenmiş olması, fiziksel bariyer onaylanana kadar (GATE_ACK) kapıyı açmaz.
              </div>
            </div>

            {/* DEC-027 Card */}
            <div className="bg-red-50/70 rounded-xl p-5 border border-red-200 text-xs text-red-950 space-y-2">
              <div className="flex items-center gap-2 font-bold text-sm text-red-900">
                <AlertTriangle className="w-4 h-4 text-red-700" />
                DEC-027: Otopark Dışı Kampüs Yolu Geçiş Ücreti Yetkisi (BLK-002)
              </div>
              <p className="leading-relaxed">
                Kamu üniversitesi arazisindeki yolların veya giriş kapılarının sadece geçiş için ücretli
                hale getirilmesi Danıştay ve Sayıştay içtihatları açısından tartışmalıdır. Üniversite Hukuk
                Müşavirliği&apos;nin yazılı uygunluk mütalaası olmadan kampüs giriş yollarında ücretli geçiş
                uygulanması kesinlikle bloke edilmiştir.
              </p>
            </div>
          </div>
        )}

        {/* TAB 6: USE CASES */}
        {activeTab === 'p01-usecases' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  İş Senaryoları Kataloğu (UC-001..UC-032)
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  P01 keşif safhasında tanımlanan 32 kullanım senaryosu ailesi ve P03 Gherkin devir planı
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="UC ID, aktör veya senaryo ara..."
                    className="pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-slate-400 w-52 sm:w-64"
                  />
                </div>

                <button
                  onClick={() => handleExportCSV('Senaryo_Katalogu', p01Data.useCases)}
                  className="flex items-center gap-1 px-3 py-1.5 text-xs rounded-lg bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5 text-slate-500" />
                  CSV İndir
                </button>
              </div>
            </div>

            {/* Family Filters */}
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                onClick={() => setSelectedUseCaseFamily('ALL')}
                className={`px-2.5 py-1 text-xs rounded-md transition-colors ${
                  selectedUseCaseFamily === 'ALL'
                    ? 'bg-slate-900 text-white font-medium'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Tüm Aileler (32)
              </button>
              {useCaseFamilies.map((fam) => (
                <button
                  key={fam}
                  onClick={() => setSelectedUseCaseFamily(fam)}
                  className={`px-2.5 py-1 text-xs rounded-md transition-colors ${
                    selectedUseCaseFamily === fam
                      ? 'bg-slate-900 text-white font-medium'
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {fam}
                </button>
              ))}
            </div>

            {/* Use Case Table */}
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
                    <tr>
                      <th className="py-3 px-4">Senaryo ID</th>
                      <th className="py-3 px-4">Aile</th>
                      <th className="py-3 px-4">Başlık</th>
                      <th className="py-3 px-4">Birincil Aktör</th>
                      <th className="py-3 px-4">Tetikleyici (Trigger)</th>
                      <th className="py-3 px-4">Beklenen Çıktı / Kanıt</th>
                      <th className="py-3 px-4">Devir Fazı</th>
                      <th className="py-3 px-4 text-right">İşlem</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredUseCases.map((uc) => (
                      <tr key={uc.use_case_id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-slate-900">
                          {uc.use_case_id}
                        </td>
                        <td className="py-3 px-4 font-medium text-slate-700">{uc.family}</td>
                        <td className="py-3 px-4 font-semibold text-slate-900 max-w-xs">
                          {uc.title}
                        </td>
                        <td className="py-3 px-4 text-slate-600">{uc.primary_actor}</td>
                        <td className="py-3 px-4 text-slate-500 max-w-xs">{uc.trigger}</td>
                        <td className="py-3 px-4 font-mono text-[11px] text-slate-600">
                          {uc.evidence_target}
                        </td>
                        <td className="py-3 px-4">
                          <span className="inline-block px-2 py-0.5 rounded bg-blue-50 text-blue-800 font-mono text-[10px] font-semibold border border-blue-200">
                            {uc.handover_phase} DEVİR
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => setSelectedDetail({ type: 'usecase', data: uc })}
                            className="text-xs font-semibold text-slate-700 hover:text-slate-900 hover:underline inline-flex items-center gap-0.5"
                          >
                            İncele
                            <ChevronRight className="w-3 h-3" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: NFR & EVIDENCE PLAN */}
        {activeTab === 'p01-nfr' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  NFR Ölçüm Matrisi ve REQ-005..013 Kanıt Planı
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  16 NFR ölçüm alanı (TO_DEFINE_OR_VERIFY) ve 9 kanonik gereksinim kanıt eşlemesi
                </p>
              </div>

              <button
                onClick={() => handleExportCSV('NFR_ve_Kanit_Plani', p01Data.nfrDiscovery)}
                className="flex items-center gap-1 px-3 py-1.5 text-xs rounded-lg bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 shadow-2xs"
              >
                <Download className="w-3.5 h-3.5 text-slate-500" />
                NFR CSV İndir
              </button>
            </div>

            {/* REQ-005..013 Evidence Matrix */}
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
              <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                <div className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                  REQ-005 &ndash; REQ-013 Kanıt Planı (p01-requirement-evidence-plan.csv)
                </div>
                <span className="text-[11px] font-mono text-amber-800 bg-amber-100 px-2 py-0.5 rounded font-semibold">
                  TÜMÜ: EVIDENCE_PENDING
                </span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-slate-100 text-slate-500 font-semibold text-[11px]">
                    <tr>
                      <th className="py-2.5 px-4">Gereksinim ID</th>
                      <th className="py-2.5 px-4">Başlık</th>
                      <th className="py-2.5 px-4">Beklenen Kanıt Türü</th>
                      <th className="py-2.5 px-4">Hedef Doküman / Çıktı</th>
                      <th className="py-2.5 px-4">Sorumlu Rol</th>
                      <th className="py-2.5 px-4">Doğrulama Yöntemi</th>
                      <th className="py-2.5 px-4">Mevcut Durum</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {p01Data.requirementEvidencePlan.map((r) => (
                      <tr key={r.requirement_id} className="hover:bg-slate-50/60">
                        <td className="py-2.5 px-4 font-mono font-bold text-slate-900">
                          {r.requirement_id}
                        </td>
                        <td className="py-2.5 px-4 font-semibold text-slate-800">{r.title}</td>
                        <td className="py-2.5 px-4 font-mono text-[11px] text-slate-600">
                          {r.evidence_target_type}
                        </td>
                        <td className="py-2.5 px-4 text-slate-700 max-w-xs">
                          {r.expected_document_or_artifact}
                        </td>
                        <td className="py-2.5 px-4 text-slate-600">{r.responsible_role}</td>
                        <td className="py-2.5 px-4 text-slate-500 text-[11px]">{r.verification_method}</td>
                        <td className="py-2.5 px-4">
                          <span className="inline-block px-2 py-0.5 rounded bg-amber-50 text-amber-800 font-semibold text-[10px] border border-amber-200">
                            {r.current_status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 16 NFR Discovery Grid */}
            <div>
              <div className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-3">
                16 NFR Ölçüm Metodolojisi ve Belirsizlik Alanları (nfr-discovery.csv)
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-3">
                {p01Data.nfrDiscovery.map((nfr) => (
                  <div
                    key={nfr.nfr_id}
                    onClick={() => setSelectedDetail({ type: 'nfr', data: nfr })}
                    className="p-4 rounded-xl bg-white border border-slate-200 hover:border-slate-300 cursor-pointer transition-all shadow-2xs space-y-2"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-mono font-bold text-slate-900">{nfr.nfr_id}</span>
                      <span className="text-[10px] font-semibold text-purple-700 bg-purple-50 px-2 py-0.5 rounded">
                        {nfr.category}
                      </span>
                    </div>
                    <h4 className="font-bold text-xs text-slate-800">{nfr.topic}</h4>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      {nfr.measurement_metric}
                    </p>
                    <div className="pt-2 border-t border-slate-100 text-[10px] text-slate-500 space-y-0.5">
                      <div>Yöntem: <span className="font-medium text-slate-700">{nfr.discovery_method}</span></div>
                      <div>Birim: <span className="font-mono text-slate-700">{nfr.unit}</span></div>
                      <div>Otorite: <span className="text-slate-700">{nfr.responsible_authority}</span></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 8: P00 GOVERNANCE & PRINCIPLES */}
        {activeTab === 'p00-governance' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  P00 Kanonik Yönetişim, Kararlar ve Değişmezler
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  56 referans ve 49 çalışma dosyasıyla korunan anayasal kütükler
                </p>
              </div>
              <span className="text-xs bg-emerald-50 text-emerald-800 px-3 py-1 rounded-md font-mono border border-emerald-200 font-semibold">
                P00 HASH AUDIT: SOURCE_HASH_PASS
              </span>
            </div>

            {/* Invariants Grid K-01..K-12 */}
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs">
              <div className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-3 flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-slate-600" />
                Bağlayıcı Mimari Değişmezler (K-01 &ndash; K-12)
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                {p00Data.invariants.map((inv) => (
                  <div key={inv.id} className="p-3.5 rounded-lg bg-slate-50 border border-slate-200/80">
                    <div className="font-mono text-xs font-bold text-slate-800">{inv.id}</div>
                    <div className="font-semibold text-xs text-slate-900 mt-1">{inv.title}</div>
                    <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">{inv.proof}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Gate Matrix G0..G9 */}
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs">
              <div className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-3 flex items-center gap-1.5">
                <ScanSearch className="w-4 h-4 text-slate-600" />
                Kurumsal Kapı Matrisi (G0 &ndash; G9)
              </div>
              <div className="space-y-2">
                {p00Data.gates.map((g) => (
                  <div
                    key={g.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-100 gap-2"
                  >
                    <div className="flex items-center gap-3">
                      <span className="font-mono font-bold text-xs bg-white px-2 py-1 rounded border border-slate-200">
                        {g.id}
                      </span>
                      <div>
                        <div className="text-xs font-bold text-slate-900">{g.phases}</div>
                        <div className="text-[11px] text-slate-500 mt-0.5">{g.evidence}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-[11px] text-slate-400">Yetkili: {g.authority}</span>
                      <span
                        className={`text-xs px-2.5 py-0.5 rounded font-mono font-semibold ${
                          g.status === 'NOT_APPROVED'
                            ? 'bg-red-50 text-red-800 border border-red-200'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {g.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Canonical Blockers List (BLK-001..008) */}
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs">
              <div className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-3 flex items-center gap-1.5">
                <FileLock2 className="w-4 h-4 text-slate-600" />
                Kanonik Açık Blokajlar (BLK-001 &ndash; BLK-008)
              </div>
              <div className="grid md:grid-cols-2 gap-3">
                {p00Data.blockers.map((b) => (
                  <div key={b.id} className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-xs text-red-800 bg-red-50 px-2 py-0.5 rounded border border-red-200">
                        {b.id}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">
                        DEC: {b.decision_ids} | REQ: {b.requirement_ids}
                      </span>
                    </div>
                    <div className="text-xs font-bold text-slate-900 mt-2">{b.description}</div>
                    <p className="text-[11px] text-slate-600 mt-1">{b.blocks}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Modal / Detail Drawer */}
      {selectedDetail && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-xl border border-slate-200 max-h-[85vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold bg-slate-100 px-2.5 py-1 rounded text-slate-700">
                  {selectedDetail.data.question_id ||
                    selectedDetail.data.use_case_id ||
                    selectedDetail.data.role_id ||
                    selectedDetail.data.nfr_id ||
                    selectedDetail.data.id}
                </span>
                <h3 className="font-bold text-sm text-slate-900">
                  {selectedDetail.data.topic ||
                    selectedDetail.data.title ||
                    selectedDetail.data.role_name ||
                    selectedDetail.data.category}
                </h3>
              </div>
              <button
                onClick={() => setSelectedDetail(null)}
                className="w-7 h-7 rounded-lg bg-slate-100 text-slate-500 hover:text-slate-900 flex items-center justify-center text-sm font-bold"
              >
                &times;
              </button>
            </div>

            <div className="space-y-3 text-xs leading-relaxed">
              {/* Question Detail */}
              {selectedDetail.type === 'question' && (
                <>
                  <div>
                    <span className="text-slate-400 font-medium">Soru Metni:</span>
                    <p className="text-sm font-semibold text-slate-900 mt-1">
                      {selectedDetail.data.question_text}
                    </p>
                  </div>
                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100">
                    <div>
                      <span className="text-slate-400">Muhatap Rol:</span>
                      <div className="font-semibold text-slate-800">
                        {selectedDetail.data.stakeholder_role}
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Durum:</span>
                      <div className="font-semibold text-amber-800">
                        {selectedDetail.data.status}
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Beklenen Kanıt:</span>
                      <div className="font-mono text-slate-700">
                        {selectedDetail.data.required_evidence}
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Yanıt Sahibi:</span>
                      <div className="font-mono text-slate-700">
                        {selectedDetail.data.response_owner}
                      </div>
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-[11px]">
                    <strong>Görüşme Kuralı:</strong> Bu soru henüz sahada kurumsal paydaşla
                    görüşülmemiştir. İmzalı tutanak ve resmi belge taranmadan yanıt verilmiş kabul
                    edilemez.
                  </div>
                </>
              )}

              {/* Use Case Detail */}
              {selectedDetail.type === 'usecase' && (
                <>
                  <div>
                    <span className="text-slate-400 font-medium">Senaryo Ailesi:</span>
                    <div className="font-bold text-slate-800 mt-0.5">
                      {selectedDetail.data.family}
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-400 font-medium">Tetikleyici (Trigger):</span>
                    <p className="text-slate-700 mt-0.5">{selectedDetail.data.trigger}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100">
                    <div>
                      <span className="text-slate-400">Ön Koşul (Precondition):</span>
                      <div className="text-slate-800 mt-0.5">
                        {selectedDetail.data.preconditions}
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Son Koşul (Postcondition):</span>
                      <div className="text-slate-800 mt-0.5">
                        {selectedDetail.data.postconditions}
                      </div>
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200 text-blue-900 text-[11px]">
                    <strong>P03 Devir Planı:</strong> Bu senaryo P03 safhasında pozitif ve negatif
                    olmak üzere en az 4 ayrı Gherkin BDD test senaryosuna dönüştürülecektir.
                  </div>
                </>
              )}

              {/* Stakeholder Detail */}
              {selectedDetail.type === 'stakeholder' && (
                <>
                  <div>
                    <span className="text-slate-400 font-medium">Kurumsal Birim:</span>
                    <div className="font-bold text-slate-800 mt-0.5">
                      {selectedDetail.data.organization_unit}
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-400 font-medium">Yetki ve Görev Kapsamı:</span>
                    <p className="text-slate-700 mt-0.5">{selectedDetail.data.mandate_scope}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100">
                    <div>
                      <span className="text-slate-400">Onay Yetkisi Düzeyi:</span>
                      <div className="font-mono text-slate-800 mt-0.5">
                        {selectedDetail.data.approval_authority}
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Atama Durumu:</span>
                      <div className="font-bold text-amber-800 mt-0.5">
                        {selectedDetail.data.status}
                      </div>
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-slate-600 text-[11px]">
                    Not: {selectedDetail.data.notes}
                  </div>
                </>
              )}

              {/* NFR Detail */}
              {selectedDetail.type === 'nfr' && (
                <>
                  <div>
                    <span className="text-slate-400 font-medium">Ölçüm Metriği:</span>
                    <p className="font-semibold text-slate-900 mt-0.5">
                      {selectedDetail.data.measurement_metric}
                    </p>
                  </div>
                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100">
                    <div>
                      <span className="text-slate-400">Keşif Yöntemi:</span>
                      <div className="text-slate-800 mt-0.5">
                        {selectedDetail.data.discovery_method}
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Ölçüm Birimi:</span>
                      <div className="font-mono text-slate-800 mt-0.5">
                        {selectedDetail.data.unit}
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Örneklem Periyodu:</span>
                      <div className="text-slate-800 mt-0.5">
                        {selectedDetail.data.sampling_period}
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Sorumlu Otorite:</span>
                      <div className="text-slate-800 mt-0.5">
                        {selectedDetail.data.responsible_authority}
                      </div>
                    </div>
                  </div>
                </>
              )}

              {/* Model Detail */}
              {selectedDetail.type === 'model' && (
                <>
                  <p className="text-slate-700 leading-relaxed">{selectedDetail.data.desc}</p>
                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100">
                    <div>
                      <span className="text-slate-400">KDV Durumu:</span>
                      <div className="font-semibold text-slate-800">
                        {selectedDetail.data.vat}
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Merchant Sahibi:</span>
                      <div className="font-semibold text-slate-800">
                        {selectedDetail.data.merchant}
                      </div>
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-[11px]">
                    <strong>Açık Blokaj (BLK-001):</strong> Rektörlük veya Yönetim Kurulu resmi işletme
                    modelini seçene kadar hiçbir mali entegrasyon canlıya alınamaz.
                  </div>
                </>
              )}
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setSelectedDetail(null)}
                className="px-4 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors"
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 px-4 sm:px-6 lg:px-8 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div>
          Kampüs PTS &middot; P01 Kurumsal ve Saha Keşfi &middot; PREVIEW_ONLY &middot; G0 NOT_APPROVED &middot; G1 NOT_STARTED
        </div>
        <div className="font-mono text-[11px] text-slate-400">
          Kanonik P00 Kaynakları P00_REFERENCE dizininde korunur
        </div>
      </footer>
    </div>
  );
}
