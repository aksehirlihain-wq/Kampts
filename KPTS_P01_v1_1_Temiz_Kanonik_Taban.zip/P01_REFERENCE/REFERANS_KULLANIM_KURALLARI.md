# P01 Eski Teknik Paketinden Alınmış Tasarım Referansları

Bu dosyalar P01 taslak kapsamı ve CSV şablonlarıdır; gerçek saha, hukuki onay veya derleme kanıtı değildir.
Orijinal P00 kökü **değiştirilmeyecek**. Bunları `docs/p01`, `evidence/P01` ve yeni validator olarak eklemek için kullan.
P01 tarihsel P01-validation-report.txt bir eski rapordur, yeni test kanıtı olarak sunulamaz.
Eksik gerçek saha bilgisi UNKNOWN/NOT_COLLECTED, iddia edilmeyen sistem bağlantısı NOT_VERIFIED olur.
