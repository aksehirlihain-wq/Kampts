# Google AI Studio — P01 Temiz Kaynak Aktarımı

1. Bu ZIP dosyasını *aç* ve proje dizininin bütün gerçek dosyalarını içe aktar. ZIP'i yalnızca asset olarak taşıma.
2. `P00_REFERENCE/`, `file-sha256.json`, `KampusPTS/` P00 kanonik dosyaları ile `P01_REFERENCE/`, `p01-reference-sha256.json` içeriğini **değiştirme**.
3. `cd KampusPTS && python3 tools/audit_source_integrity.py` sonucu **56/56 49/49** olmalıdır.
4. `cd KampusPTS && python3 tools/audit_p01_canonical.py` sonucu PASS olmalıdır.
5. `cd KampusPTS && python3 tools/validate_p01.py && python3 -m unittest discover -s tests -v` çalıştır.
6. Sonrasında `npm run lint && npm run build` çalıştır; başarısızlığı gizleme.
7. Yalnızca `src/**` ve yeni P01 destek dosyalarında sunum düzeltmesi yap; referans içeriğini baştan yazma.
8. `G0 NOT_APPROVED`, `G1 NOT_STARTED`, `DATA_NOT_COLLECTED`, `LIVE NO-GO` korunur.
9. Kurumsal backend, GeoVision üretici kanalının gerçek yetkisi veya saha keşfi tamamlandı diye iddia etme.
10. P02’ye geçme; tam ZIP'i geri teslim et.
