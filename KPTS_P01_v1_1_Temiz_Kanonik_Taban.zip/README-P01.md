# Kampüs PTS P01 — Temiz Kanonik Teknik Taban

Bu proje, 30.10.2026 tarihli P01 Google AI Studio teslimindeki kaynak sapmalarını düzeltmek için **doğrulanmış P00 v1.3 kaynakları** ve **orijinal P01 teknik referansları** temel alınarak oluşturuldu.

- `P00_REFERENCE/` — orijinal 56 kaynak; `KampusPTS/` — P00'ı içeren 49 donmuş çalışma kaynağı
- `P01_REFERENCE/` — 38 tarihsel/kanonik referans dosyası (36 çalışma kaynağı, 2 referans/historik)
- `KampusPTS/docs/p01/data/` — özgün 17 CSV şeması ve özgün başlangıç satırları
- `KampusPTS/tools/audit_p01_canonical.py` — P00+P01 hash/şema/başlangıç durumu bağımsız denetimi
- `src/` — AI Studio'dan alınan P01 önizleme, **türetilmiş kaynak veriye bağlanmış**, kurumsal backend veya canlı mod değil
- `P01-test-results.txt` — çalıştırılmış Python denetimi ve doğrulanamayan React build açık ayrılmış
- `P01-AI-STUDIO-IMPORT.md` — AI Studio aktarım yönergesi

## Bağımsız doğrulama

```bash
cd KampusPTS
python3 tools/audit_source_integrity.py
python3 tools/audit_p01_canonical.py
python3 tools/validate_p00.py
python3 tools/validate_p01.py
python3 -m unittest discover -s tests -v
```

`G0 NOT_APPROVED`, `G1 NOT_STARTED`, `DATA_NOT_COLLECTED`, `LIVE NO-GO`. React build bu ortamda `NOT_RUN` (npm çevrimdışı bağımlılık eksikliği). Kaynak bütünlüğü PASS canlı üretim kabulü değildir.
